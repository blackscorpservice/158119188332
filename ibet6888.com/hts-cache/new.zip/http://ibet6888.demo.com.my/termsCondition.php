<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - termsCondition</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li  ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li  ><a href="FAQ.php">FAQ</a></li>
                <li class="cur-nav" ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li  ><a href="privacy.php">Privacy Policy</a></li>
                <li  ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li  ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li  ><a href="FAQ.php">FAQ</a></li>
                        <li class="cur-nav" ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li  ><a href="privacy.php">Privacy Policy</a></li>
                        <li  ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>
<div class="content">
    <h1>Terms of Rules</h1>
    <ul class="article-list">
        <li class="article expend">
            <div class="article-title">General Terms and Rules</div>
            <div class="article-content" style="display: block;">
                <ul>
                    <li>By registering to use the services covered by these Terms and Conditions and/or by playing at iBET (hereinafter each separately and all together collectively referred to as "iBET" or "Site"), you are certifying that you are 18 years of age or older, and you represent and warrant that you have read, fully understand and agree to be bound by and to comply with these "Terms and Conditions." If you do not wish to accept the following terms and conditions, you must not register and open an account and you will be unable to access the software and the gaming services offered in conjunction therewith.</li>
                    <li>Product information, registration on the site, use of any services offered and all and any bets accepted by the iBET are subject to these "Terms and Conditions".</li>
                    <li>iBET reserves the right to amend these "Terms and Conditions" at any time without prior notification. Such amendments shall become effective and in force immediately upon being posted in this "Terms and Conditions" section of the iBET website. It is your responsibility to review the "Terms and Conditions" on a regular basis. Your continued use of the Site after a change or update has been made to "Terms and Conditions" will constitute your acceptance of such change or update.</li>
                    <li>These "Terms and Conditions" represent the complete, final and exclusive agreement between you and iBET and will supersede and merge all prior agreements, representations and understandings between you and iBET. You confirm that, in agreeing to accept these Terms and Conditions, you have not relied on any representation save insofar as the same has expressly been made a representation in these “Terms and Conditions”.</li>
                    <li>In case of contradiction between a provision of this Agreement and any provision on the iBET website, the provision of this Agreement shall prevail.</li>
                    <li>We reserve the right at our own discretion to request you to furnish us with a proof of your identity and age as a precondition before we allow you to participate in any iBET gaming activities.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Accounts conditions of use</div>
            <div class="article-content">
                <ul>
                    <li>Where there is any dispute concerning a Player's account, iBET reserves the right to suspend the Player's account until a resolution is reached. Any disputes must be lodged in writing stating the date, time and details of dispute and sent via email to <a href="mailto:ibetcs.my@gmail.com">ibetcs.my@gmail.com</a> iBET takes customer disputes very seriously and endeavours to take all reasonable steps to investigate and resolve all disputes.</li>
                    <li>iBET reserves the right to suspend, cancel your account for any reason whatsoever at any time without notice to you. Any balance in your account at the time of such cancellation will be refunded to you using a method of payment as determined by iBET. However, iBET reserves the right, at its sole discretion, to void any winnings and forfeit any balance in your iBET account or any other winnings or entitlements you might otherwise have or have had from your iBET account and your use of iBET services or/and Play.</li>
                    <li>You are solely responsible for keeping your account number and password secure. You shall not allow any other person or third party including, without limitation, any minor, to use or reuse your iBET account, access and/or use any materials or information from the iBET Website, accept any prize, or Play at iBET . You are solely responsible for any purchases and/or losses incurred by yourself or a third party on your iBET account.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">General Terms &amp; Conditions of Promotion</div>
            <div class="article-content">
                <ul>
                    <li>All offers is restricted to only one free open account per individual, family, household address, email address, telephone number, bank account and IP address.</li>
                    <li>Any bets placed on two opposite sides, tie and void bets will not be taken into the calculation of the casino rebate or count towards any rollover requirement.</li>
                    <li>We reserve the right to alter, amend or terminate this Promotion, or any aspect of it, at any time and without prior notice.</li>
                    <li>Each customer is only allowed to have one registered account in iBET. If any customers are found to create more than one account,(Before creating multiple accounts, customers have to contact one of our live chat representative and request for creating multiple accounts). Otherwise iBET will treat these accounts as an arbitrage betting account. And iBET has the right to terminate the accounts, and credit will be frozen permanently.</li>
                    <li>At iBET's discretion, you may be requested by iBET to provide identification information. It is mandatory that you furnish the requested information upon our notification. If you do not provide the requested information, you agree to give up your rights to any balances left in your iBET account.</li>
                    <li>By participating in the Promotion, you confirm that the name and address that are registered in your account are correct and up to date. Failure to provide this information may lead to disqualification from the Promotion.</li>
                    <li>Bonus claim within promotion period by using bonus/coupon credit and bets in slot games, if won Jackpot from the accumulated prize pool, Jackpot pool prize winning amount will be fully donated to philanthropic institutions in Philippines (Customers may request for the receipt of donation).</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Wagering</div>
            <div class="article-content">
                <ul>
                    <li>Acceptance and Validation of Wagering:
                        <ul>
                            <li>Wager<br>Player must wager from funds that are in their Player accounts. All wagering is void if on review the Player has never successfully deposited funds or Funds Transfer into their respective Player account. After deposit, your total bet must be more than 100% or equivalent of your deposit amount, or we will unable to apply for withdrawal, please make the deposit amount on demand.</li>
                            <li>Confirmed Wagers<br>iBET cannot cancel wagers once they have been confirmed by iBET in your account, unless the wager is declared void or due to incorrect results &amp; settlement for reasons outlined in these Terms &amp; Conditions.</li>
                            <li>Accurate Wagering Records<br>Despite every effort to ensure total accuracy, we do not accept responsibility for any errors or omissions in respect of information provided on the Website.</li>
                            <li>Deduction of Wagers / Unresolved Wagers<br>Stakes will be deducted from your account at the time of placing your wager, no matter when the result is determined. iBET cannot refund wagers placed on games where wagers have been purchased for future draws that have not yet been resolved. Such wagers will be resolved upon completion of such games and winnings, if applicable, credited to Players accounts at that time.</li>
                            <li>iBET Wagering Decision is Final<br>You agree that iBET and its records shall be the final authority in determining the terms of any wagers you place and the circumstances in which they were made.</li>
                            <li>Players Sole Responsibility for Winnings<br>Any applicable taxes and fees in connection with any winnings awarded to you or any other payments to you are your sole responsibility. iBET may report and withhold any amount from your winnings in order to comply with any applicable law. Winnings cannot be transferred, substituted or redeemed for any other winnings.</li>
                        </ul>
                    </li>
                    <li>Stakes Wagered:
                        <ul>
                            <li>Minimum Stakes<br>A minimum stake, dependent on the particular Game, will apply.</li>
                            <li>Server Evidenced Wager Results<br>In the event that there is a discrepancy between either the numbers that a Player believes that they have entered or the graphic display of the game they have played and those in the database maintained by iBET, the numbers in the database will be deemed to be valid.</li>
                            <li>Automatic Game Playing / Manipulation of Software / Tampering / Cheating<br>Automatic playing of Games by software or any other manipulation of the Games or your/another Player's account data are strictly prohibited and may result in termination of your membership, deletion of all associated accounts, the cancellation and/or confiscation of any outstanding prizes and deposits and civil/criminal prosecution. In addition to the above, you agree that iBET has the complete and unfettered discretion to terminate your account for any reason whatsoever and, without limiting the generality of the foregoing, should it be of the opinion that your participation in the site, or any games offered therein, is detrimental to the principles under which it operates the site. You hereby waive any and all recourse against iBET for any such termination. You acknowledge that full freedom from errors or incompleteness is impossible to achieve with respect to computer software. Should you become aware that the software contains such error or incompleteness you undertake to refrain from taking any advantage whatsoever thereof. Moreover, promptly upon becoming aware of such error or incompleteness you shall notify iBET in writing. Should you fail to fulfill your undertakings under this clause, iBET shall be entitled to full compensation for all costs, including costs for rectifying the software that may arise out of your omissions or actions in taking advantage of such errors or incompleteness. You agree that iBET is not responsible for any damage, loss, or injury resulting from tampering, or other unauthorized access or use of the site or your account. Any attempt by you to gain unauthorized access to the site's systems or any account, interfere with procedures or performance of the site or games, or deliberately damage or undermine the site or Games is subject to civil and/or criminal prosecution and will result in immediate termination of your account and forfeiture of any and all prizes to which you may have been otherwise entitled to.</li>
                            <li>Events Beyond iBET’s Control<br>Wherever possible, iBET endeavours to ensure the full protection of all its Players and their wagers. However, there are certain events that are beyond iBET's control. Should you become disconnected from the site (for whatever reason), any act of God, iBET cannot be held liable for any losses that may result there from. Should a Player be disconnected after placing a wager and before the game is played, the results of that game will still be displayed on the Players account and any winnings or losses recorded accordingly.</li>
                            <li>Wager Result Acceptance<br>By placing any further wagers with iBET, the Player accepts the results of any previous wagers. As such, the results of the previous wagers are hereby deemed no longer in dispute and no refunds or other adjustments will be granted.</li>
                            <li>Software Malfunction<br>iBET reserves the right to withhold winnings and void wagers if a Player manipulates the games in a fraudulent manner or the software itself malfunctions.</li>
                        </ul>
                    </li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Winnings</div>
            <div class="article-content">
                <ul>
                    <li>Prior to releasing or approving any withdrawal, iBET reserves the right to request customers to furnish information such as proof of Personal Identification, front and back copy of credit card/debit card, Passport, Driving License or recent bank statement or other appropriate documentation as iBET, at its sole discretion, deems necessary. If you fail to comply with any security request, iBET reserves the right to void any winnings in your account.</li>
                    <li>Crediting Winnings - Winnings will be added to your respective Account, as appropriate, automatically. These updates of your accounts are not 'proof of win' and or should the funds have been transferred (debited) from your respective Account. If upon manual review there is evidence of fraud or malpractice, iBET reserves the right to void certain winnings and to amend your various accounts accordingly.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Win Limits</div>
            <div class="article-content">
                <div>The following are the maximum winnings, in U.S Dollar or equivalent amount in other currencies, which may be won online per day by an individual:
                    <ol>
                        <li>100,000 for Casino and other games</li>
                        <li>100,000 for fixed-odds Games
                            <ol type="a">
                                <li>These winnings are exclusive of stake and this should be considered when staking your wager. Where selections taken from different categories are combined in multiple or accumulative wagers the lowest maximum winnings limit will apply.</li>
                                <li>iBET management reserves the right to reduce or change win limits without prior notice.</li>
                                <li>iBET reserves the right to cancel any winnings inadvertently provided by our system which exceeds these limits.</li>
                            </ol>
                        </li>
                        <li>iBET sportbooks maximum payout for Mix Parlay/Correct Score is MYR 70,000.</li>
                    </ol>
                </div>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Bonus Money</div>
            <div class="article-content">
                <ul>
                    <li>Bonus money is the virtual money given to casino / KENO customers for promotional purposes. The customers cannot withdraw such money right after they have been given it. Depending on the type of bonus, different bonus money processing rules may apply.</li>
                    <li>Bonus money can be converted to real money and then withdrawn after a customer fulfills the requirements of the particular promotion.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Other Service Provisions</div>
            <div class="article-content">
                <p>You shall be solely responsible and agree to pay all fees you incur, as well as to report and pay all applicable taxes as required by the applicable governing law while using any services of iBET .</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Miscellaneous</div>
            <div class="article-content">
                <p>If this Terms and Conditions are translated into another language, the English version will prevail.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Disclaimer</div>
            <div class="article-content">
                <ul>
                    <li>You shall hold iBET, its employees, officers, directors, shareholders, licensees, distributors, wholesalers, parents, affiliates, subsidiaries, advertising, promotion or other agencies, media partners, agents and suppliers harmless immediately on demand and shall fully indemnify same from any and all claims, losses, costs, damages, liabilities and expenses whatsoever (including legal fees) that may arise from or be asserted by any third party.</li>
                    <li>iBET will not be responsible or liable to you for any loss of content or material uploaded or transmitted through the Play and you confirm that we shall not be liable to you or any third party for any modification to, suspension of or discontinuance of the Play.</li>
                    <li>iBET pledges to offer both fair and timely dispute resolutions and redress without undue cost or burden, holding detailed wager and transaction records of all its financial dealings. These records are archived for a period of 5 years (from the date of transaction) and are accessible to the dispute resolution authority upon request.</li>
                </ul>
            </div>
        </li>

    </ul>
</div>
   
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>