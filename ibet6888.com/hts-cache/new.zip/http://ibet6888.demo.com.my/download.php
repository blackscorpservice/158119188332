
<!DOCTYPE html>
<html lang="en">


<head>

    <title>Sugar Bet - 🏆 Malaysia's Best Online Casino Betting Website</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Sugar Bet is the best Online Casino Malaysia, we provide live casino, sports betting, slots game, and online 4D lottery. Enjoy best online gaming in Malaysia.">
    <link rel="alternate" href="index.html" hreflang="en" />
<link rel="shortcut icon" href="Images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="Images/favicon.ico">

    <link rel="stylesheet" href="Css/bootstrap.min.css?v=1568047808" />
    <link rel="stylesheet" href="Css/all.css?v=1" >
    <link rel="stylesheet" href="Css/jquery.mmenu.all.css">
    <link rel="stylesheet" href="Css/icon-font.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="Css/slick.css" />
    <link rel="stylesheet" type="text/css" href="Css/slick-theme.min.css" />
    <link rel="stylesheet" href="Css/bootstrap-select.min.css">
    <link rel="stylesheet" href="Css/owl.carousel.min.css">

    <link rel="stylesheet" href="Css/style.css?v=1568047809" />

    <script src="Scripts/jquery-3.3.1.min.js" ></script>
    <script src="Scripts/popper.min.js" ></script>
    <script src="Scripts/bootstrap.min.js" ></script>
    <script src="Scripts/jquery.mmenu.all.js"></script>
    <script src="Scripts/jquery.touchSwipe.min.js"></script>
    <script type="text/javascript" src="Scripts/slick.min.js"></script>
    <script src="Scripts/jquery.marquee.min.js" type="text/javascript"></script>
    <script src="Scripts/bootstrap-select.min.js"></script>
    <script src="Scripts/jquery.matchHeight-min.js"></script>
    <script src="Scripts/script-head.js"></script>
    <script type="application/ld+json">
        {
        "@context": "http://schema.org",
        "@type": "EntertainmentBusiness",
        "additionalType": [
        "https://en.wikipedia.org/wiki/Online_casino",
        "https://en.wikipedia.org/wiki/Malaysia",
        "https://en.wikipedia.org/wiki/Online_gambling"
        ],
        "name": "Sugar Bet gives you the best online betting experience in Malaysia",
        "description": "Sugar Bet ONLINE ENTERTAINMENT CITY was established in the Philippines in 2013 and have since expanded across Asia. Sugar Bet is a host to more than 30 most popular online gaming platforms from Europe to Asia, providing members with over 1000 online games. We offer the best online casino experience in Malaysia and is committed to customer safety and privacy. Our games are certified and internationally recognized, and the site uses SSL encryption only to give you a safe and reliable online betting platform with the widest gameplay choices. In addition to our highly-recommended Live casino games, we also provide Sports betting, Online slots games and 4D Lottery Betting. Not only you get to bet with your favorite games, you can now enjoy them in full privacy too anytime, anywhere on your favorite smart devices. Of course, at Sugar Bet it is more than winning, read on to find out more on what else we have in store for you to fulfill your every entertainment need. It is just like visiting Las Vegas, only virtually in our digital entertainment platform.",
        "image": "resource/Images/ibet-logo2.svg",
        "priceRange": "$10 - $100000",
        "openingHours": "Mo-Su",
        "url": "https://t.co/C34OM5OVaR#online-casino-malaysia",
        "logo": {
        "@type": "ImageObject",
        "url": "https://lh3.googleusercontent.com/--MPFOxLNhYw/AAAAAAAAAAI/AAAAAAAAAAs/AzLboTjeA9Y/s60-p-rw-no-il/photo.jpg",
        "width": {
        "@type": "QuantitativeValue",
        "value": 250
        },
        "height": {
        "@type": "QuantitativeValue",
        "value": 250
        }
        },
        "sameAs": [
        "https://instagram.com/p/BobSPVKH8js",
        "https://www.facebook.com/ibetpromotion/",
        "https://www.youtube.com/watch?v=4g_X6v8Dp0k",
        "https://plus.google.com/u/1/116920268656739249906",
        "https://www.pinterest.com/ibet6888en/",
        "https://www.reddit.com/user/ibet6888en/",
        "https://twitter.com/ibet6888en"
        ],
        "areaServed": [
        {
        "@type": "Country",
        "name": "Malaysia",
        "url": "https://www.wikidata.org/wiki/Q833"
        }
        ],
        "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Online Casino Malaysia",
        "itemListElement": [
        {
        "@type": "Offer",
        "itemOffered": "Service",
        "name": "Live Caino",
        "url": " live-casino.html"
        },
        {
        "@type": "Offer",
        "itemOffered": "Service",
        "name": "Sport Betting",
        "url": "sport-betting.html"
        },
        {
        "@type": "Offer",
        "itemOffered": "Service",
        "name": "Online Slot game",
        "url": "online-slots.html"
        },
        {
        "@type": "Offer",
        "itemOffered": "Service",
        "name": "Lottery 4D",
        "url": "online-4d.html"
        }
        ]
        },
        "Review": {
        "@type": "Review",
        "name": "Online Casino Malaysia",
        "author": {
        "@type": "Person",
        "name": "Online Casino Player"
        },
        "datePublished": "2019-04-18T15:22:11+01:00",
        "reviewRating": {
        "@type": "Rating",
        "ratingValue": "5.0"
        }
        }
        }
    </script>
</head><script type="text/javascript">
    </script>
<body class="preload">
    <div id="mm-wrapper">
        

        <header class="">
            <div id="topbar" class="">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-6 col-lg-2">
                            <a class="navbar-toggler" id="responsive-menu-button" href="#my-menu">
                                <div id="nav-icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <a href="index.php" class="site-logo"><img src="Images/Logo_300x119.png?V=11" alt="Sugar Bet" /></a>
                        </div>
                        <div class="col-lg-10 col-6 text-right">
                            <div class="d-none d-lg-block">
                                <div class="row no-gutters align-items-center justify-content-end">
                                    <div class="col-auto pr-3">
                                        <form class="form-inline" action="#" method="post">
                                            <div class="form-group mr-3">
                                                <label for="username1" class="sr-only">Username</label>
                                                <input type="text" name="username" class="form-control" required  placeholder="Username">
                                            </div>
                                            <div class="form-group mr-3">
                                                <label for="password1" class="sr-only">Password</label>
                                                <div class="password-holder">
                                                    <input type="password" name="password"  class="form-control" required placeholder="Password">
                                                    <!--<button type="button" data-toggle="modal" data-target="#fpModal" class="btn btn-light forgot-trigger">Forgot?</button>-->
                                                </div>
                                            </div>
                                            <!--
                                            <div class="form-group mr-3" id="TopLoginValidation">
                                                <label for="topbar-verify" class="sr-only">Validation Code</label>
                                                <div class="verify-holder">
                                                    <input type="text" class="form-control" id="Top_valid" onkeypress="TopLoginEnterEvent(event)" onkeyup="ValidCNword(this)" onblur="ValidCNword(this)" placeholder="Verify">
                                                    <div class="img-verify">
                                                        <a href="javascript:;" class="lnk-refresh bg-refresh" onclick="GetNewVcode('TopLoginVCode', '#TopLoginVCodeImg');">
                                                            <img id="" src="Images/Vcode.gif" width="80" height="42">
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        -->
                                            <input type="hidden" name="token_login" value="18c3d5af39d70068c6137e1bdc7c4b64">
                                            <button type="submit" class="btn btn-shadow btn-primary" id="" href="Profile/Profile.php">Sign in</a>
                                        </form>
                                    </div>
                                    <div class="col-auto">
                                        <div class="lang-picker">
                                            <select class="langpick selectpicker">
                                            <option data-content="<img src='Images/24x24-icon_english.svg'/> English" data-href="language.php?lang=en&link=https%3A%2F%2Fibet6888.demo.com.my%2F%2Fdownload.php" selected="selected" >English</option>
                                            <option data-content="<img src='Images/24x24-icon_chinese.svg'/> 简体中文" data-href="language.php?lang=zh&link=https%3A%2F%2Fibet6888.demo.com.my%2F%2Fdownload.php"  >简体中文</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <a href="register.php" class="btn-link text-white d-block d-lg-none" style="float:right">Register</a>
                            <a href="#" class="btn-link text-white d-block d-lg-none" data-toggle="modal" data-target="#loginModal" style="float:right">Sign in /&nbsp</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <nav class="yamm site-nav navbar navbar-light">
            <div class="container">
                <ul class="nav">
                    <li class="nav-item i-home">
                        <a href="index.php" class="nav-link nav-home"><i class="material-icons">home</i> <img src="Images/Logo_300x146.png?v=121" /></a>
                    </li>
                    <li class="nav-item i-app">
                        <a href="#app" class="nav-link"><i class="material-icons">phone_iphone</i></a>
                    </li>
                    
                            <li class="nav-item dropdown yamm-fullwidth">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                CASINO
                            
                                    <span class="lnr lnr-chevron-down"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <div class="yamm-content">
                                            <div class="row">
                                                <div class="col-4">
                                                    <div class="nav-card">
                                                           <div class="tag">
                                                                <span class="tag-NEW"></span>
                                                                <span class="tag-text">NEW</span>
                                                            </div>
                                                           
                                                        
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col-5">
                                                                <div class="nav-game" style="background-image: url(allbet.png);">
                                                                </div>
                                                            </div>
                                                            <div class="col-7">
                                                                <span class="h3">Allbet</span>
                                                                <div class="game-info">
                                                                    <span class="i-info bg-info-pc"></span>
                                                                    <span class="i-info bg-info-html5"></span>
                                                                </div>
                                                                <div class="game-go">
                                                                    <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="nav-item dropdown yamm-fullwidth">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                SPORT
                            </a>
                            </li>
                            
                            <li class="nav-item dropdown yamm-fullwidth">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                SLOTS
                            
                                    <span class="lnr lnr-chevron-down"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <div class="yamm-content">
                                            <div class="row">
                                                <div class="col-4">
                                                    <div class="nav-card">
                                                        
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col-5">
                                                                <div class="nav-game" style="background-image: url(aztec.png);">
                                                                </div>
                                                            </div>
                                                            <div class="col-7">
                                                                <span class="h3">Inca Jackpot (New!)</span>
                                                                <div class="game-info">
                                                                    <span class="i-info bg-info-pc"></span>
                                                                    <span class="i-info bg-info-html5"></span>
                                                                </div>
                                                                <div class="game-go">
                                                                    <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-4">
                                                    <div class="nav-card">
                                                        
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col-5">
                                                                <div class="nav-game" style="background-image: url(gtsje.png);">
                                                                </div>
                                                            </div>
                                                            <div class="col-7">
                                                                <span class="h3">Jade Emperor (New!)</span>
                                                                <div class="game-info">
                                                                    <span class="i-info bg-info-pc"></span>
                                                                    <span class="i-info bg-info-html5"></span>
                                                                </div>
                                                                <div class="game-go">
                                                                    <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                            
                            <li class="nav-item dropdown yamm-fullwidth">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                LOTTERY
                            </a>
                            </li>
                            
                            <li class="nav-item dropdown yamm-fullwidth">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                GameWeLove
                            
                                    <span class="lnr lnr-chevron-down"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <div class="yamm-content">
                                            <div class="row">
                                                <div class="col-4">
                                                    <div class="nav-card">
                                                           <div class="tag">
                                                                <span class="tag-NEW"></span>
                                                                <span class="tag-text">NEW</span>
                                                            </div>
                                                           
                                                        
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col-5">
                                                                <div class="nav-game" style="background-image: url(allbet.png);">
                                                                </div>
                                                            </div>
                                                            <div class="col-7">
                                                                <span class="h3">Allbet</span>
                                                                <div class="game-info">
                                                                    <span class="i-info bg-info-pc"></span>
                                                                    <span class="i-info bg-info-html5"></span>
                                                                </div>
                                                                <div class="game-go">
                                                                    <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                                                <!--
                    <li class="nav-item dropdown yamm-fullwidth">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
Casino
<span class="lnr lnr-chevron-down"></span>
</a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1510.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">TGP</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1630.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">MAYA</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1530.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IPT</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                            <a class="btn btn-sm btn-primary" href="download.php">Download</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1160.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IAG</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                            <a class="btn btn-sm btn-primary" href="download.php">Download</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1040.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">iCasino+</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1460.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">Allbet</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1090.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">iCasino++</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1190.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">GD</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1240.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">BBIN</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1330.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">MG</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                            <a class="btn btn-sm btn-primary" href="download.php">Download</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1210.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">Opus</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card nav-game-hall">
                                                <a href="live-casino.html">
                                                    <span class="h3">Casino Gameroom <i class="fas fa-chevron-right"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown yamm-fullwidth">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
Sport
<span class="lnr lnr-chevron-down"></span>
</a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1140.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IBIT Sport</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1500.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IMSB</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1440.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">ESPORT</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card nav-game-hall">
                                                <a href="sport-betting.html">
                                                    <span class="h3">Sport Gameroom <i class="fas fa-chevron-right"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown yamm-fullwidth">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
Slots
<span class="lnr lnr-chevron-down"></span>
</a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">

                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1580.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">918KISS</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1510.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">TGP</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1160.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IAG</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                            <a class="btn btn-sm btn-primary" href="download.php">Download</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1530.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">IPT</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1480.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">PP</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1460.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">Allbet</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1180.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">S888</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-hot"></span>
                                                    <span class="tag-text">hot</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1190.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">GD</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1320.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">HB</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1330.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">MG</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-download"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                            <a class="btn btn-sm btn-primary" href="download.php">Download</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1380.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">KUMA</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1420.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">AMEBA</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1430.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">SG</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1400.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">DT</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-apple"></span>
                                                            <span class="i-info bg-info-android"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card nav-game-hall">
                                                <a href="online-slots.html">
                                                    <span class="h3">Slots Gameroom <i class="fas fa-chevron-right"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown yamm-fullwidth">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
Lottery
<span class="lnr lnr-chevron-down"></span>
</a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1170.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">iLottery/4D</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card">
                                                <div class="tag">
                                                    <span class="tag-new"></span>
                                                    <span class="tag-text">new</span>
                                                </div>
                                                <div class="row no-gutters align-items-center">
                                                    <div class="col-5">
                                                        <div class="nav-game" style="background-image: url(Images/imgColor-1250.png);">
                                                        </div>
                                                    </div>
                                                    <div class="col-7">
                                                        <span class="h3">GB</span>
                                                        <div class="game-info">
                                                            <span class="i-info bg-info-pc"></span>
                                                            <span class="i-info bg-info-html5"></span>
                                                        </div>
                                                        <div class="game-go">
                                                            <a class="btn btn-sm btn-primary" data-toggle="modal" data-target="#loginModal" href="#">Play Now</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="nav-card nav-game-hall">
                                                <a href="online-4d.html">
                                                    <span class="h3">Lottery Gameroom <i class="fas fa-chevron-right"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a href="download.php" class="nav-link">Download</a>
                    </li>
                    <li class="nav-item">
                        <a href="promotion.php" class="nav-link">Promotion</a>
                    </li>
                    -->
                    <li class="nav-item nav-signup">
                        <a href="register.php" class="nav-link">SIGN UP</a>
                    </li>
                    
                </ul>
            </div>
        </nav>
        <div id="mobile-navigation">
            <nav id="my-menu" class="nav">
                <ul class="upper">
                    <li class="mobile-nav-icon icon-home"><a href="index.php">Home</a></li>
                    <li class="mobile-nav-icon icon-casino"><a href="live-casino.html">Casino</a></li>
                    <li class="mobile-nav-icon icon-sport"><a href="sport-betting.html">Sport</a></li>
                    <li class="mobile-nav-icon icon-slots"><a href="online-slots.html">Slots</a></li>
                    <li class="mobile-nav-icon icon-lottery"><a href="online-4d.html">Lottery</a></li>
                    <li class="mobile-nav-icon icon-download border-bottom"><a href="download.php">Download</a></li>
                    <li class="mobile-nav-icon icon-promotion"><a href="FileUpload/promos-mobile-C-en-us.html">Promotion</a></li>
                    <li class="mobile-nav-icon icon-bonus"><a href="#" data-toggle="modal" data-target="#loginModal">Bonus Points</a></li>
                    <li class="mobile-nav-icon icon-deposit"><a href="#" data-toggle="modal" data-target="#loginModal">Deposit</a></li>
                    <li class="mobile-nav-icon icon-withdrawal"><a href="#" data-toggle="modal" data-target="#loginModal">Withdrawal</a></li>
                    <li class="mobile-nav-icon icon-transfer"><a href="#" data-toggle="modal" data-target="#loginModal">In-site Transfer</a></li>
                    <li class="mobile-nav-icon icon-message border-bottom"><a href="#" data-toggle="modal" data-target="#loginModal">Message</a></li>
                    <li class="mobile-nav-icon icon-help"><a href="#">Help Center</a></li>
                    <li class="mobile-nav-icon icon-livechat"><a href="javascript:MM_openBrWindow('https://secure.livechatinc.com/licence/2816672/open_chat.cgi?groups=0', '联络我们', 420, 530)">LiveChat</a></li>
                    <li class="mobile-nav-icon icon-feedback"><a href="#" data-toggle="modal" data-target="#complaintsModal" onclick="CleanOpinionServiceModal();">Feedback</a></li>
                    <li class="mobile-nav-icon icon-callback"><a href="#" data-toggle="modal" data-target="#callbackModal">Callback Service</a></li>
                    <li class="mobile-nav-icon icon-profile"><a href="#" data-toggle="modal" data-target="#loginModal">Profile</a></li>
                    <li>
                        <span class="lang-nav"><img src='Images/24x24-icon_english.svg' /> English</span>
                        <ul class="Vertical">
                            <li class="active">
                                <a href="index.php"><img src='Images/24x24-icon_english.svg' /> English</a>
                            </li>
                            <li>
                                <a href="zh/index.php"><img src='Images/24x24-icon_chinese.svg' /> 简体中文</a>
                            </li>
                        </ul>

                    </li>
                </ul>
            </nav>
        </div>
        <div id="bottom-bar">
            <div class="container">
                <div class="row no-gutters">
                    <div class="col">
                        <a href="#" data-toggle="modal" data-target="#loginModal">
                            <img src="Images/nav/icon_deposit-outline.svg" alt=""> Deposit
                        </a>
                    </div>
                    <div class="col">
                        <a href="#" data-toggle="modal" data-target="#loginModal">
                            <img src="Images/nav/icon_bonus-outline.svg" alt=""> Bonus
                        </a>
                    </div>
                    <div class="col">
                        <a href="FileUpload/promos-mobile-C-en-us.html">
                            <img src="Images/nav/icon_promotion-outline.svg" alt=""> Promotion
                        </a>
                    </div>
                    <div class="col">
                        <a href="javascript:MM_openBrWindow('https://secure.livechatinc.com/licence/2816672/open_chat.cgi?groups=0', '联络我们', 420, 530)">
                            <img src="Images/nav/icon_livechat-outline.svg" alt=""> LiveChat
                        </a>
                    </div>
                    <div class="col">
                        <a href="#" data-toggle="modal" data-target="#loginModal">
                            <img src="Images/nav/icon_profile-outline.svg" alt=""> My Account
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="inner-banner" style="background-image: url(resource/img/in-banner04.jpg);">
            <div class="container">
                <h1 style="color: white;padding: 80px 0;font-weight: 300;margin: 0;position: relative;z-index: 9;">
                    <div class="heading-icon download"></div>
                    DOWNLOAD
                </h1>
            </div>
        </div>
        <div class="bg-darkgrey">
            <div class="container">
                <ul class="nav nav-pills mb-3" id="platforms" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="pills-app-tab" data-toggle="pill" href="#app-tab" role="tab" aria-controls="app-tab" aria-selected="true">APP</a>
                    </li>
                    <li class="nav-item d-none d-lg-block">
                        <a class="nav-link" id="pills-pc-tab" data-toggle="pill" href="#pills-pc" role="tab" aria-controls="pills-pc" aria-selected="true">Downloads for PC</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-mobile-tab" data-toggle="pill" href="#pills-mobile" role="tab" aria-controls="pills-mobile" aria-selected="false">Mobile</a>
                    </li>
                    <li class="nav-item d-none d-lg-block">
                        <a class="nav-link" id="pills-browser-tab" data-toggle="pill" href="#pills-browser" role="tab" aria-controls="pills-browser" aria-selected="false">Browser</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="body-content">
            <div class="container">
                <div class="tab-content" id="platforms-content">
                    <div class="tab-pane fade show active" id="app-tab" role="tabpanel" aria-labelledby="pills-app-tab">
                        <ul id="apps-options" class="download-tabs nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <a id="apps-link-1" href="#apps-1" class="nav-link active" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/apple.svg');"></div>
                                        <div class="label">iOS</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="apps-link-2" href="#apps-2" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/android.svg');"></div>
                                        <div class="label">Android</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div id="apps-content" class="download-content tab-content" role="tablist">
                            <div id="apps-1" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="apps-link-1">
                                <div class="card-header" role="tab" id="apps-heading-1">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/apple.svg');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">iOS</span>
                                            <p>No.1 brand of Mobile entertainment, Neverending stimulation, Instant betting, play anywhere, anytime.</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="http://www.ibet33.com/NoneLogin/ezAppDownloadApp" target="_blank" class="btn btn-primary btn-sm">Download</a>
                                            <a href="http://www.ibet33.com/App/guide_ios" target="_blank" class="btn btn-primary btn-sm">Guide</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-apps-1" class="collapse" role="tabpanel" aria-labelledby="apps-heading-1">
                                    <div class="card-body">
                                        <div class="row ">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-app-ios.png" alt="iBET iOS APP">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iOS</span>
                                                <p>No.1 brand of Mobile entertainment, Neverending stimulation, Instant betting, play anywhere, anytime.</p>
                                                <div class="row align-items-center">
                                                    <div class="col-3">
                                                        <img class="img-qrcode" src="resource/img/download-app-bg-qrcode.jpg" alt="">
                                                    </div>
                                                    <div class="col-4">
                                                        <a href="http://www.ibet33.com/App/guide_ios" class="btn btn-sm btn-primary btn-outlined btn-shadow" target="_blank">Guide</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="apps-2" class="card tab-pane fade" role="tabpanel" aria-labelledby="apps-link-2">
                                <div class="card-header" role="tab" id="apps-heading-2">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/android.svg');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">Android</span>
                                            <p>Diversified Mobile Entertainment platform, wonderful moments anytime, anywhere, everything within your grasp.</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="http://www.ibet33.com/NoneLogin/ezAppDownloadApp" target="_blank" class="btn btn-primary btn-sm">Download</a>
                                            <a href="http://www.ibet33.com/App/guide_android" target="_blank" class="btn btn-primary btn-sm">Guide</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-apps-2" class="collapse" role="tabpanel" aria-labelledby="apps-heading-2">
                                    <div class="card-body">
                                        <div class="row ">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-app-android.png" alt="iBET Android APP">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">Android</span>
                                                <p>Diversified Mobile Entertainment platform, wonderful moments anytime, anywhere, everything within your grasp.</p>
                                                <div class="row align-items-center">
                                                    <div class="col-3">
                                                        <img class="img-qrcode" src="resource/img/download-app-bg-qrcode.jpg" alt="">
                                                    </div>
                                                    <div class="col-4">
                                                        <a href="http://www.ibet33.com/App/guide_android" class="btn btn-sm btn-primary btn-outlined btn-shadow" target="_blank">Guide</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-pc" role="tabpanel" aria-labelledby="pills-pc-tab">
                        <ul id="pc-options" class="download-tabs nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <a id="pc-link-1" href="#pc-1" class="nav-link active" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1530.png');"></div>
                                        <div class="label">iPT</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="pc-link-2" href="#pc-2" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1160.png');"></div>
                                        <div class="label">iAG</div>
                                    </div>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a id="pc-link-4" href="#pc-4" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1330.png');"></div>
                                        <div class="label">MG</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div id="pc-content" class="download-content tab-content" role="tablist">
                            <div id="pc-1" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="pc-link-1">
                                <div id="collapse-pc-1" class="collapse" role="tabpanel" aria-labelledby="pc-heading-1">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-pc-1530.png" alt="iPT Downloads For PC">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iPT Downloads For PC</span>
                                                <p>Live casino & best Slot games by the famous Playtech group</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">Simple</a>
                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">Complete</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Sign In Account:Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="pc-2" class="card tab-pane fade" role="tabpanel" aria-labelledby="pc-link-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 d-none d-lg-block">
                                            <img class="img-fluid" src="resource/img/download-pc-1160.png" alt="iAG Downloads For PC">
                                        </div>
                                        <div class="col-lg-6">
                                            <span class="h3">iAG Downloads For PC</span>
                                            <p>Live casino games by the famous AG group</p>

                                            <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">Windows XP</a>
                                            <div class="mt-3">
                                                <p>
                                                    Login Account: Please login to view account.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="pc-4" class="card tab-pane fade" role="tabpanel" aria-labelledby="pc-link-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 d-none d-lg-block">
                                            <img class="img-fluid" src="resource/img/download-pc-1330.png" alt="MG Downloads For PC">
                                        </div>
                                        <div class="col-lg-6">
                                            <span class="h3">MG Downloads For PC</span>
                                            <p>More than hundreds of electronic games and live version of PLAYBOY play</p>

                                            <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">Windows XP</a>
                                            <div class="mt-3">
                                                <p>
                                                    Login Account: Please login to view account.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-mobile" role="tabpanel" aria-labelledby="pills-mobile-tab">
                        <ul id="mobile-options" class="download-tabs nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <a id="mobile-link-1" href="#mobile-1" class="nav-link active" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1530.png');"></div>
                                        <div class="label">iPT</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-2" href="#mobile-2" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1160.png');"></div>
                                        <div class="label">iAG</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-3" href="#mobile-3" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1090.png');"></div>
                                        <div class="label">iCASINO++</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-4" href="#mobile-4" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1040.png');"></div>
                                        <div class="label">iCASINO+</div>
                                    </div>
                                </a>
                            </li>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-5" href="#mobile-5" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1180.png');"></div>
                                        <div class="label">S888</div>
                                    </div>
                                </a>
                            </li>
                            </li>

                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-7" href="#mobile-7" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1210.png');"></div>
                                        <div class="label">OPUS</div>
                                    </div>
                                </a>
                            </li>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-8" href="#mobile-8" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1400.png');"></div>
                                        <div class="label">DT</div>
                                    </div>
                                </a>
                            </li>
                            </li>
                            <li class="nav-item">
                                <a id="mobile-link-9" href="#mobile-9" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/imgColor-1460.png');"></div>
                                        <div class="label">Allbet</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div id="mobile-content" class="download-content tab-content" role="tablist">
                            <div id="mobile-1" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="mobile-link-1">
                                <div class="card-header" role="tab" id="mobile-heading-1">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1530.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">iPT Mobile</span>
                                            <p>Live casino & best Slot games by the famous Playtech group</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-1" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-1">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1530.png" alt="iPT Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iPT Mobile</span>
                                                <p>Live casino & best Slot games by the famous Playtech group</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-2" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-2">
                                <div class="card-header" role="tab" id="mobile-heading-2">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1160.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">iAG Mobile</span>
                                            <p>Live casino games by the famous AG group</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-2" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-2">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1160.png" alt="iAG Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iAG Mobile</span>
                                                <p>Live casino games by the famous AG group</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-3" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-3">
                                <div class="card-header" role="tab" id="mobile-heading-3">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1090.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">iCASINO++ Mobile</span>
                                            <p>Try your luck in our Central Eastern Casino!(Slot only offers mobile client betting)</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-3" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-3">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1090.png" alt="iCASINO++ Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iCASINO++ Mobile</span>
                                                <p>Try your luck in our Central Eastern Casino!(Slot only offers mobile client betting)</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-4" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-4">
                                <div class="card-header" role="tab" id="mobile-heading-4">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1040.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">iCASINO+ Mobile</span>
                                            <p>Try your luck in our central eastern casino! Slot only on mobile</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-4" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-4">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1040.png" alt="iCASINO+ Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">iCASINO+ Mobile</span>
                                                <p>Try your luck in our central eastern casino! Slot only on mobile</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-5" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-5">
                                <div class="card-header" role="tab" id="mobile-heading-5">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1180.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">S888 Mobile</span>
                                            <p>Win Big with exciting slot games and Big Jackpots!!</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-5" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-5">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1180.png" alt="S888 Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">S888 Mobile</span>
                                                <p>Win Big with exciting slot games and Big Jackpots!!</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="mobile-7" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-7">
                                <div class="card-header" role="tab" id="mobile-heading-7">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1210.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">OPUS Mobile</span>
                                            <p>Live casino games by the famous OPUS group</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-7" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-7">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1210.png" alt="OPUS Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">OPUS Mobile</span>
                                                <p>Live casino games by the famous OPUS group</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-8" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-8">
                                <div class="card-header" role="tab" id="mobile-heading-8">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1400.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">DT Mobile</span>
                                            <p>Full of childhood memories, youthful blood and feelings, the most brilliant slot machine in the DT Game Gallery</p>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-8" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-8">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1400.png" alt="DT Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">DT Mobile</span>
                                                <p>Full of childhood memories, youthful blood and feelings, the most brilliant slot machine in the DT Game Gallery</p>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="mobile-9" class="card tab-pane fade" role="tabpanel" aria-labelledby="mobile-link-9">
                                <div class="card-header" role="tab" id="mobile-heading-9">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col-2 col-md-1">
                                            <div class="icon" style="background-image: url('resource/img/imgColor-1460.png');"></div>
                                        </div>
                                        <div class="col-6 col-sm-7 col-md-8 pr-2">
                                            <span class="h3">Allbet Mobile</span>
                                        </div>
                                        <div class="col-4 col-sm-3 col-md-3 text-center">
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">CASINO</a>
                                            <a href="#" data-toggle="modal" data-target="#loginModal" class="btn btn-primary btn-sm">SLOTS</a>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapse-mobile-9" class="collapse" role="tabpanel" aria-labelledby="mobile-heading-9">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-mobile-1460.png" alt="Allbet Mobile">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3 mb-3">Allbet Mobile</span>

                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">CASINO</a>
                                                <a href="#" class="btn btn-primary btn-shadow btn-wide" data-toggle="modal" data-target="#loginModal">SLOTS</a>
                                                <div class="mt-3">
                                                    <p>
                                                        Login Account: Please login to view account.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-browser" role="tabpanel" aria-labelledby="pills-browser-tab">
                        <ul id="browser-options" class="download-tabs nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <a id="browser-link-1" href="#browser-1" class="nav-link active" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/100x100-firefox.png');"></div>
                                        <div class="label">Firefox</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="browser-link-2" href="#browser-2" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/100x100-ie.png');"></div>
                                        <div class="label">IE</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="browser-link-3" href="#browser-3" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/100x100-chrome.png');"></div>
                                        <div class="label">Chrome</div>
                                    </div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a id="browser-link-4" href="#browser-4" class="nav-link" data-toggle="tab" role="tab">
                                    <div class="download-pill">
                                        <div class="icon" style="background-image: url('resource/img/100x100-flash.png');"></div>
                                        <div class="label">Flash</div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div id="browser-content" class="download-content tab-content" role="tablist">
                            <div id="browser-1" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="browser-link-1">
                                <div id="collapse-browser-1" class="collapse" role="tabpanel" aria-labelledby="browser-heading-1">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-lg-6 d-none d-lg-block">
                                                <img class="img-fluid" src="resource/img/download-browser-firefox.png" alt="Downloads FireFox for Browser">
                                            </div>
                                            <div class="col-lg-6">
                                                <span class="h3">Downloads FireFox for Browser</span>
                                                <p>Faster and Furthter Browser, The browser just made for you.</p>
                                                <a href="https://www.mozilla.org/en-my/firefox/" rel="nofollow" class="btn btn-primary btn-shadow btn-wide" target="_blank">Download</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="browser-2" class="card tab-pane fade" role="tabpanel" aria-labelledby="browser-link-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 d-none d-lg-block">
                                            <img class="img-fluid" src="resource/img/download-browser-ie.png" alt="Downloads Internet Explorer for Browser">
                                        </div>
                                        <div class="col-lg-6">
                                            <span class="h3">Downloads Internet Explorer for Browser</span>
                                            <p>Internet Explorer: faster, simpler ,more secluded and more secure.</p>
                                            <a href="https://support.microsoft.com/en-my/help/17621/internet-explorer-downloads" rel="nofollow" class="btn btn-primary btn-shadow btn-wide" target="_blank">Download</a>
                                            <div class="mt-3">
                                                <p>
                                                    Login Account: Please login to view account.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="browser-3" class="card tab-pane fade" role="tabpanel" aria-labelledby="browser-link-3">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 d-none d-lg-block">
                                            <img class="img-fluid" src="resource/img/download-browser-chrome.png" alt="Downloads Chrome for Browser">
                                        </div>
                                        <div class="col-lg-6">
                                            <span class="h3">Downloads Chrome for Browser</span>
                                            <p>Download the fast free browser for PC, mobile phone and tablet.</p>
                                            <a href="https://www.google.com/intl/en/chrome/browser/desktop/" rel="nofollow" class="btn btn-primary btn-shadow btn-wide" target="_blank">Download</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="browser-4" class="card tab-pane fade" role="tabpanel" aria-labelledby="browser-link-4">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 d-none d-lg-block">
                                            <img class="img-fluid" src="resource/img/download-browser-flash.png" alt="Downloads Flash Player for Browser">
                                        </div>
                                        <div class="col-lg-6">
                                            <span class="h3">Downloads Flash Player for Browser</span>
                                            <p>Flash Player installed on more than 1.3 billion systems, provide great and rich web experience.</p>
                                            <a href="https://get.adobe.com/en/flashplayer/" rel="nofollow" class="btn btn-primary btn-shadow btn-wide" target="_blank">Download</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<footer>
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                    <span class="h3">INFORMATION</span>
                    <ul>
                        <li><a href="policy.php" target="_blank" rel="nofollow">VIP Policy</a></li>
                        <li><a href="about.php" target="_blank" rel="nofollow">About Us</a></li>
                        <li><a href="termsCondition.php" target="_blank" rel="nofollow">Terms & Conditions</a></li>
                        <li><a href="privacy.php" target="_blank" rel="nofollow">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                    <span class="h3">USER GUIDE</span>
                    <ul>
                        <li><a href="en-blog/index.html" target="_blank">Help Center</a></li>
                        <li><a href="deposit.php" target="_blank" rel="nofollow">Deposit Guideline</a></li>
                        <li><a href="withdrawal.php" target="_blank" rel="nofollow">Withdrawal Help</a></li>
                    </ul>
                </div>
                <div class="col-xl-4 col-lg-2 d-none d-lg-block">
                    <span class="h3">BROWSERS</span>
                    <div class="row browser-list">
                        <div class="col-xs-2 col-lg-5 col-xl-3 mb-3">
                            <a href="https://support.microsoft.com/en-my/help/17621/internet-explorer-downloads" target="_blank" rel="nofollow">
                                <img src="Images/32x32-icon_footer-ie.svg" alt=""> IE
                            </a>
                        </div>
                        <div class="col-xs-2 col-lg-5 col-xl-3 mb-3">
                            <a href="https://www.mozilla.org/en-my/firefox/#" target="_blank" rel="nofollow">
                                <img src="Images/32x32-icon_footer-firefox.svg" alt=""> Firefox
                            </a>
                        </div>
                        <div class="w-100"></div>
                        <div class="col-xs-2 col-lg-5 col-xl-3 mb-3">
                            <a href="https://www.google.com/intl/en/chrome/browser/desktop/" target="_blank" rel="nofollow">
                                <img src="Images/32x32-icon_footer-chrome.svg" alt=""> Chrome
                            </a>
                        </div>
                        <div class="col-xs-2 col-lg-5 col-xl-3 mb-3">
                            <a href="https://get.adobe.com/en/flashplayer/" target="_blank" rel="nofollow">
                                <img src="Images/32x32-icon_footer-flash.svg" alt=""> Flash
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <span class="h3">BANK PAYMENTS</span>
                    <ul class="bank-list">
                        <li><img src="Images/bank-maybank.jpg" alt="Maybank"></li>
                        <li><img src="Images/bank-public.jpg" alt="Public Bank"></li>
                        <li><img src="Images/bank-cimb-1.jpg" alt="CIMB"></li>
                        <li><img src="Images/bank-hongleong.jpg" alt="Hong Leong"></li>
                        <li><img src="Images/bank-rhb.jpg" alt="RHB"></li>
                        <li><img src="Images/bank-bsn.jpg" alt="BSN"></li>
                        <li><img src="Images/bank-ambank.jpg" alt="AmBank"></li>
                    </ul>
                    <span class="h3">NEW TO Sugar Bet?</span>
                    <p>
                        Leave your details to receive the latest offers.                    </p>
                    <form action="#" method="post">
                        <div class="form-group row mb-2 mb-sm-0 no-gutters">
                            <div class="col-8 col-md-4 col-lg-8">
                                <label for="email" class="sr-only">Email</label>
                                <input type="email" class="form-control" id="membermail" placeholder="Your email address" onkeydown="clearSubscribeErrorMsg();">
                            </div>
                            <div class="col-4 col-md-2 col-lg-4 pl-3">
                                <button type="button" onclick="SubscribeNewsFeed_StaticPage();" class="btn btn-shadow btn-block btn-primary">SEND</button>
                            </div>
                            <span id="subscription_error" class="txt-remindOrange"></span> Copyright © 2019
                    </form>
                    </div>
                </div>
                <div class="copyright">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-lg-auto mb-2 mb-lg-0 pagcor">
                            <img src="Images/logo-pagcor.svg" alt="PAGCOR" class="mr-2 mb-2 mb-lg-0 d-block d-lg-inline-block"> License Number 16-0031, and regulated by the Philippine Amusement and Gaming Corporation.
                        </div>
                        <div class="col-lg-auto mb-2 mb-lg-0">
                            Copyright © 2018 Sugar Bet. All Rights Reserved.
                        </div>
                    </div>
                </div>
            </div>
    </footer>
    </div>
    <div class="sc-deposit-wrapper">
        <div class="container">
            <div id="sc-deposit" class="sc-float" data-toggle="modal" data-target="#loginModal">
                <i class="fas fa-university"></i>Deposit Slip Shortcut<span class="lnr lnr-chevron-up"></span>
            </div>
        </div>
    </div>

    <div class="sc-float" id="sc-luckydraw" data-toggle="modal" data-target="#loginModal">
        <img src="Images/gift.svg" data-toggle="popover" class="hoverpop" data-placement="right" data-html="true">

    </div>

    <div class="sc-float" id="sc-contact">
        <ul class="list-unstyled">
            <li data-toggle="popover" class="hoverpop" data-placement="left" data-content="LiveChat">
                <a href="javascript:MM_openBrWindow('https://secure.livechatinc.com/licence/2816672/open_chat.cgi?groups=0', '联络我们', 420, 530)"><img src="Images/headset.svg" /></a>
            </li>
            <li data-toggle="popover" class="hoverpop" data-placement="left" data-html="true" data-content="<img class='qrcode' src='Images/wechatqrcode.jpg' /> welcome_ibet2">
                <a href="#"><img src="Images/wechat.svg" /></a>
            </li>
            <li data-toggle="popover" class="hoverpop" data-placement="left" data-content="Feedback">
                <a href="#" data-toggle="modal" data-target="#complaintsModal" onclick="CleanOpinionServiceModal();"><img src="Images/complaints.svg" /></a>
            </li>
            <li data-toggle="popover" class="hoverpop" data-placement="left" data-content="Callback Service">
                <a href="#" data-toggle="modal" data-target="#callbackModal"><img src="Images/call.svg" /></a>
            </li>
        </ul>
    </div>
    <div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
        <div class="modal-dialog modal-smaller modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="h5 modal-title">Sign In</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span class="lnr lnr-cross"></span>
</button>
                </div>
                <div class="modal-body">
                    <form class="pop_login" action="#" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input name="username" type="text" class="form-control" id="Login_Account" onkeypress="LoginEnterEvent(event)" onkeyup="ValidCNword(this)" onblur="ValidCNword(this)" placeholder="Username">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <div class="password-holder">
                                <input name="password" type="password" class="form-control" id="Login_Password" onkeypress="LoginEnterEvent(event)" placeholder="Password">
                                <!--<button type="button" data-toggle="modal" data-target="#fpModal" class="btn btn-light forgot-trigger" data-dismiss="modal">Forgot?</button>-->
                            </div>
                        </div>
                        <!--
                        <div class="form-group" id="BoxLoginValidation">
                            <label class="d-block" for="login-verify">Validation Code</label>
                            <div class="verify-holder w-85 d-inline-block">
                                <input type="text" class="form-control" id="valid" onkeypress="LoginEnterEvent(event)" onkeyup="ValidCNword(this)" onblur="ValidCNword(this)" name="valid" maxlength="4">
                                <span class="img-verify"><img id="" src="Images/Vcode.gif" width="82" height="42"></span>
                            </div>
                            <a href="#" class="refresh-verify d-inline-block ml-2" onclick="GetNewVcode('boxloginvcode', '#BoxLoginCodeImg');"><i class="fas fa-sync"></i></a>
                        </div>-->

                        <div class="ipt-area">
                            <p class="txt-remindRed" id="BoxLoginMsg"></p>
                        </div>
                        <div class="text-right">
                            <a href="register.php" class="btn btn-shadow btn-outlined btn-primary mr-3 btn-wide">Sign Up</a>
                            <button type="submit" class="btn btn-shadow btn-primary btn-wide" >Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="fpModal" tabindex="-1" role="dialog" aria-labelledby="fpModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="h5 modal-title">Find My Password</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span class="lnr lnr-cross"></span>
</button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-6">
                                <a href="javascript:MM_openBrWindow('https://secure.livechatinc.com/licence/2816672/open_chat.cgi?groups=0', '联络我们', 420, 530)">
                                    <div class="find-password-action">
                                        <div class="blue-box live-chat">
                                        </div>
                                        <span class="h3">LiveChat</span>
                                        <p>
                                            Please contact our customer service to submit the required information to certify and prove ownership of account.
                                        </p>
                                        <div class="btn btn-link">
                                            Live Chat <span class="lnr lnr-chevron-right"></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-6">
                                <a href="#" data-toggle="modal" data-target="#fpEmailModal" data-dismiss="modal">
                                    <div class="find-password-action">
                                        <div class="blue-box email">
                                        </div>
                                        <span class="h3">Email</span>
                                        <p>
                                            Please submit the member account, we'll send the new password to your mailbox.
                                        </p>
                                        <div class="btn btn-link">
                                            Email <span class="lnr lnr-chevron-right"></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="fpEmailModal" tabindex="-1" role="dialog" aria-labelledby="fpEmailModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="h5 modal-title">E-Mail</span>
                    <button type="button" id="close_fpEmail" class="close" data-dismiss="modal" aria-label="Close">
<span class="lnr lnr-cross"></span>
</button>
                </div>
                <div class="modal-body">
                    <span class="h3 text-highlight mb-3">Get the password back by using e-mail</span>
                    <form class="mt-4" action="#" method="post">
                        <div class="form-group">
                            <label for="fp-username">User Name</label>
                            <input type="text" class="form-control" id="FPAccount" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="fp-email">Registered E-mail</label>
                            <input type="email" class="form-control" id="FPMail" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="fp-verify" class="d-block">Verify Number</label>
                            <div class="verify-holder w-85 d-inline-block">
                                <input id="FPVCode" name="FPVCode" type="text" class="form-control" placeholder="" maxlength="4">
                                <div class="img-verify">
                                    <img id="" src="Images/Vcode.gif"  width="82" height="42" />
                                </div>
                            </div>
                            <a href="#" class="refresh-verify d-inline-block ml-2" onclick="GetNewVcode('fp_vcode', '#FPVcodeImg');"><i class="fas fa-sync"></i></a>
                        </div>
                        <div class="text-right">
                            <button type="button" class="btn btn-shadow btn-primary btn-wide" onclick="FPSendMail();">Submit</button>
                        </div>
                        <div class="ipt-area">
                            <p class="ui-remindText" style="color:#e91e63" id="Msg"></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="complaintsModal" tabindex="-1" role="dialog" aria-labelledby="complaintsModal" aria-hidden="true">
        <div class="modal-dialog modal-smaller modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="h5 modal-title">Feedback</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span class="lnr lnr-cross"></span>
</button>
                </div>
                <div class="modal-body">
                    <span class="h3 text-highlight mb-3">Provide us any opinion or suggestion</span>
                    <p class="text-small">
                        You can provide us with any encouragement or complaints to improve our services.
                    </p>
                    <form class="mt-4" action="#" method="post">
                        <div class="form-group">
                            <label for="">Satisfaction</label>
                            <div class="">
                                <a class="satisfiction img-complaints bg-happy" title="Happy" data-bind="111"></a>
                                <a class="satisfiction img-complaints bg-friendly" title="Friendly" data-bind="222"></a>
                                <a class="satisfiction img-complaints bg-surprised" title="Surprised" data-bind="333"></a>
                                <a class="satisfiction img-complaints bg-crying" title="Crying" data-bind="444"></a>
                                <a class="satisfiction img-complaints bg-angry" title="Angry" data-bind="555"></a>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Opinion Type</label>
                            <div class="">
                                <select class="ui-select form-dropdown selectpicker" id="ddl_OpinionType" name="ddl_OpinionType">
<option value="">Please Select</option>
<option value="2">Deposit problem</option>
<option value="1">Withdrawal problem</option>
<option value="3">Connection problem</option>
<option value="4">Promotion</option>

<option value="5">Other</option>
</select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="mobile-email">Mobile or Email</label>
                            <input type="text" class="form-control" id="txtOpinionContact" name="txtOpinionContact" placeholder="" value="">
                        </div>
                        <div class="form-group">
                            <label for="comment">Comment</label>
                            <textarea name="comment" id="txtOpinion" rows="3" class="form-control"></textarea>
                        </div>
                        <div class="ui-input">
                            <div id="OpinionMsg" class="ui-remindText" style="color: #e91e63;"></div>
                        </div>
                        <div class="text-right">
                            <button type="button" class="btn btn-shadow btn-primary btn-wide" onclick="OpinionSubmit()">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="callbackModal" tabindex="-1" role="dialog" aria-labelledby="callbackModal" aria-hidden="true">
        <div class="modal-dialog modal-smaller modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="h5 modal-title">Callback Service</span>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span class="lnr lnr-cross"></span>
</button>
                </div>
                <div class="modal-body">
                    <span class="h3 text-highlight mb-3">Please leave your details. We will contact you as soon as possible.</span>
                    <form class="mt-4" action="#" method="post">
                        <div class="form-group">
                            <label for="full-name">Full Name</label>
                            <input type="text" class="form-control" id="cbs_name" name="cbs_name" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="tel" class="form-control" id="cbs_phone" name="cbs_phone" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="">Consult Type</label>
                            <div class="">
                                <select class="form-dropdown selectpicker" id="ddl_ConsultItem">
<option selected>Please Select</option>
<option>Game Platform</option>
<option>Bonus Promotion</option>
<option>Register Related</option>
<option>Deposit / Withdrawal</option>
<option>Others</option>
</select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="d-block" for="login-verify">Validation Code</label>
                            <div class="verify-holder w-85 d-inline-block">
                                <input id="cbs_validation_code" name="cbs_validation_code" type="text" class="form-control" placeholder="" maxlength="4">
                                <div class="img-verify">
                                    <img id="VcodeImg_CallbackService" width="82" height="42">
                                </div>
                            </div>
                            <a href="#" class="refresh-verify d-inline-block ml-2" onclick="GetNewVcode('CBScode', '#VcodeImg_CallbackService');"><i class="fas fa-sync"></i></a>
                        </div>
                        <div class="text-right">
                            <button type="button" class="btn btn-shadow btn-primary btn-wide" onclick="SubmitCallbackConsult_StaticPage()">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade browser-check-modal" id="browserCheckModal" tabindex="-1" role="dialog" aria-labelledby="browserCheckModal" aria-hidden="true">
        <div class="modal-dialog modal-smaller browser-check" role="document">
            <div class="content-box">
                <div class="browser-check">
                    <span class="icon-check"></span>
                </div>
                <div class="arrow-box">
                    <span class="icon-arrow"></span>
                </div>
                <div class="content">
                    <div class="title">
                        To ensure the more consistent browsing quality and website experience, we recommend that use browser to open the website
                    </div>
                    <button class="btn-close">
<span class="icon-close"></span>
</button>
                </div>
            </div>
        </div>
    </div>

    <div class="lay-loading">
        <div class="ui-loader">
            <div class="loader">
                <span class="dot dot_1"></span>
                <span class="dot dot_2"></span>
                <span class="dot dot_3"></span>
                <span class="dot dot_4"></span>
            </div>
        </div>
    </div>

    <script src="Scripts/detectmobilebrowser.js"></script>
    <script src="Scripts/pgw-browser.min.js"></script>
    <script src="Scripts/owl.carousel.min.js"></script>
    <script src="Scripts3_5/System/pgwbrowser.js"></script>
    <script src="Scripts3_5/System/Common.js"></script>
    <script src="Scripts3_5/UserDefine/VUC_MailModel.js"></script>
    <!--<script src="Scripts3_5/UserDefine/NoneLogin_Login_StaticPage.js"></script>
    <script src="Scripts3_5/Resource/en-us/NoneLogin_Login.js"></script>-->
    <script src="Scripts3_5/Resource/en-us/Common.js"></script>
    <script src="Scripts3_5/Resource/en-us/SiteFloating.js"></script>
    <script src="Scripts3_5/Resource/en-us/VUC_MailModel.js"></script>
    <script src="Scripts3_5/UserDefine/SiteFloating_StaticPage.js"></script>
    <script src="Scripts3_5/Design/select.min.js"></script>
    <script src="Scripts/script-body.js?v=11"></script>
    <script src="Scripts3_5/jquery.validate.js"></script>

    <script>
        $(document).ready(function () {
            $("#closeAdBtn").click(function () {
                $(".adbar").hide();
            });
            // 20190327 關閉右下懸浮畫面
            $(".close-ad-btn").click(function () {
                $(this).parent().remove();
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            var URL = document.location.origin;
            $(".pop_login").validate({
                submitHandler: function(form) {
                    var opt = ""; $(".lay-loading").show();
                    $.ajax({                       
                        type: "POST",
                        url: URL+"/Require/ajax_poplogin.php",
                        data: new FormData(form),
                        cache: false,
                        dataType: "json",
                        contentType: false,
                        processData: false,      
                        success: function( data ) { 
                            if(data.code == 1){
                                window.location.href = URL+"/Profile/Profile.php";
                            }else{
                                alert(data.msg);
                            }
                        $(".lay-loading").fadeOut("slow"); 
                        }
                    });
                }
            });

            // 20190409 修復banner輪播功能
            var initBanner = function () {
                var indexBanner = $('#index_banner');

                var timeMs = 8000;

                var bannerOwl = indexBanner.find('.owl-carousel').owlCarousel({
                    animateOut: 'fadeOut',
                    loop: true,
                    items: 1,
                    // nav: true,
                    autoplay: true,
                    autoplayTimeout: timeMs,
                    autoplayHoverPause: false,
                    onTranslate: onTranslate,
                    onInitialized: onInitialized
                });

                //手動觸發
                indexBanner.find('.banner-promo-list li').on('click', function () {
                    var position = $(this).data('position');

                    // 切換Banner顯示
                    activeBanner(position);
                    bannerOwl.trigger('to.owl.carousel', [position, 300]);
                });

                function onInitialized(event) {
                    onTranslate(event);
                }

                function onTranslate(event) {
                    var page = event.page.index === -1 ? 0 : event.page.index;
                    activeBanner(page);
                }

                function activeBanner(position) {
                    var list = indexBanner.find('.banner-promo-list');

                    // 切換Banner導覽按鈕
                    list.find('li[data-position="' + position + '"]').addClass('active').siblings().not('li[data-position="' + position + '"]').removeClass('active');

                    // 進度條
                    list.not('li.active').find('.banner-progress').attr('style', 'width:0');
                    list.find('li.active .banner-progress').attr('style', 'width:100%;transition: width ' + timeMs + 'ms linear;');
                }
            };
        
        var pgwBrowser = $.pgwCustomBrowser();
                if (pgwBrowser.device.mobile) {
                    //重新綁定輪播功能
                    $('.banner-slider').slick({
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        arrows: false,
                        dots: false,
                        fade: true,
                        pauseOnFocus: false,
                        asNavFor: '.banner-nav',
                        autoplay: false,
                        autoplaySpeed: 7000,
                        draggable: false,

                        responsive: [
                            {
                                breakpoint: 991,
                                settings: {
                                    dots: true,
                                    fade: false,
                                }
                            },
                        ],
                    });
                    $('.banner-nav').slick({
                        slidesToShow: 5,
                        slidesToScroll: 5,
                        asNavFor: '.banner-slider',
                        dots: false,
                        focusOnSelect: true,
                        swipe: false,
                        draggable: false,
                    });
                }
                else {

                    initBanner();
                }
            });
        $(function () {
            //是否維護中
            CheckIsMaintenance();

            //產生驗證碼
            GetNewVcode('CBScode', '#VcodeImg_CallbackService');
            GetNewVcode('fp_vcode', '#FPVcodeImg');

            /* 換圖因此不須此連結(保留功能，因時常換圖)
            //若裝置為手機,則替換活動連結
            var pgwBrowser = $.pgwCustomBrowser();
            if(pgwBrowser.device.mobile)
            {
                $('.ad-promos-en').attr('href','../../FileUpload/promos-mobile-C-en-us.html');
            }
            */

            //取得Banner內容
            var url = "/VUC/JackpotBanner_StaticPage";
            var DataObject = {
                Lang: "en-us",
            };
            var successfun = function (context) {

                //若為禁止瀏覽的區域則移除內文顯示禁止頁面內容
                if(context.indexOf("<!DOCTYPE html>") != -1)
                {
                    $('body').empty();
                    $("body").html(context);
                    return;
                }
                
                $("#index_banner").html(context);

                

            };
            var errorfun = function () {
                console.log("BannerError");
            };
            AjaxPostFuncHtml(url, DataObject, successfun, errorfun);
        });
    </script>
    <script>

    </script>
</body>

<!-- Mirrored from ibet6888.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:23:51 GMT -->

</html>