<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - privacy</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li  ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li  ><a href="FAQ.php">FAQ</a></li>
                <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li class="cur-nav" ><a href="privacy.php">Privacy Policy</a></li>
                <li  ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li  ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li  ><a href="FAQ.php">FAQ</a></li>
                        <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li class="cur-nav" ><a href="privacy.php">Privacy Policy</a></li>
                        <li  ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>
<div class="content">
    <h1>Security Privacy Policy</h1>
    <ul class="article-list">
        <li class="article expend">
            <div class="article-title">Privacy Policy</div>
            <div class="article-content" style="display: block;">
                <p>This is the privacy policy ("Privacy Policy") of iBET (the "Operator") and explains how the Operator receives, uses and protects your personal information. Protecting your privacy and your personal information is important to the Operator.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Applicability Of This Privacy Policy</div>
            <div class="article-content">
                <p>By using this Website, you (the "Customer") agree to the terms of this Privacy Policy and the use and disclosure of your personal information as set out in this Privacy Policy. The Operator will review this Privacy Policy periodically, and reserves the right to modify and update this Privacy Policy at any time.</p>
                <p>Changes to this Privacy Policy will come into effect immediately upon such changes being notified on this Website by a prominent notice. The Customer's continued use of this Website following such notification will constitute the Customer's acceptance of these changes. The Operator recommends that the Customer reviews this Privacy Policy periodically.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Information Collected And Its Use</div>
            <div class="article-content">
                <p>The Operator collects personal information when the Customer uses this Website and information about the transactions the Customer undertakes including details of payments used. Where such details of payments used are provided, they are stored in a fully encrypted format and are not accessible by the Operator. Such personal information includes, but is not limited to, the Customer's name, date of birth, residential address, email address and phone number. The Customer may be asked to provide personal information when the Customer registers for any account with the Operator or otherwise uses this Website or the betting services provided via this Website (the "Internet Betting Facilities").</p>
                <p>In addition, when the Customer interacts with this Website and/or the Internet Betting Facilities, the Operator's servers keep an activity log unique to the Customer that collects certain administrative and traffic information including: source IP address, time of access, date of access, web page(s) visited, language use, software crash reports and type of browser used. Such details are essential for the provision of and the quality of this Website and the Internet Betting Facilities.</p>
                <p>The Operator may collect personal information from third parties including financial institutions and credit providers for the purpose of maintaining the Customer's account and conducting credit or other financial checks, and the Customer consents to the Operator's collection and use of the Customer's personal information for these purposes.</p><span>The Customer's personal information will be used:</span>
                <ol class="list-style-eng-upper" type="A">
                    <li>to set up, manage and administer the Customer's account</li>
                    <li>to make, settle and pay bets or wagers</li>
                    <li>for statistical purposes</li>
                    <li>for market research and data analysis purposes</li>
                    <li>to analyse the Customer's credit risk (if applicable)</li>
                    <li>to improve the quality or service and gaming experience for the customers</li>
                    <li>to comply with such licensing and regulatory requirements as are applicable</li>
                </ol>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Accuracy of Personal Information</div>
            <div class="article-content">
                <p>It is the Customer's responsibility to notify the Operator of any changes in their personal information by sending an email to the Operator at <a href="mailto:ibetcs.my@gmail.com">ibetcs.my@gmail.com</a> If the Customer believes any of its personal information held by the Operator is incorrect or inaccurate, the Customer may request corrections or changes to such personal information by contacting the Operator at <a href="mailto:ibetcs.my@gmail.com">ibetcs.my@gmail.com</a> and providing the Operator with the Customer's Account ID and the details that the Customer wishes to change.</p>
                <p>To obtain a copy of the personal information the Operator holds about you or if you have any queries regarding this Privacy Policy or the Operator's practices please contact the Operator at <a href="mailto:ibetcs.my@gmail.com">ibetcs.my@gmail.com</a></p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Disclosures</div>
            <div class="article-content">
                <div>The Operator may disclose the Customer's personal information:
                    <ol class="list-style-eng-upper" type="A">
                        <li>if required to do so by law</li>
                        <li>if the Operator believes in good faith that such action is necessary to:
                            <ol class="list-style-lower-roman" type="i">
                                <li>comply with any legal process served on the Operator, this Website or the Internet Betting Facilities</li>
                                <li>protect and defend the Operator's rights or property</li>
                                <li>act to protect the personal safety of users of this Website, the Internet Betting Facilities or the public</li>
                            </ol>
                        </li>
                        <li>to any regulatory body or licensing body or authority</li>
                        <li>to third parties for the purposes of settling or making payment in connection with any bet or wager</li>
                        <li>to the Customer’s intermediary betting provider (if any)</li>
                        <li>to any payment management company providing payment solution services to the Operator</li>
                        <li>to third parties who provide services to or on the Operator's behalf</li>
                        <li>to any third party that purchases the Operator or its business</li>
                    </ol>
                </div>
                <p>If, in the Operator sole determination, the Customer is found to have cheated or attempted to defraud the Operator or any other user of the Internet Betting Facilities in any way including but not limited to bet manipulation or payment fraud, or if the Operator suspects the Customer of fraudulent payment, including use of stolen credit cards, or any other fraudulent activity (including any chargeback or other reversal of a payment) or prohibited transaction (including money laundering), the Operator reserves the right to share this information (together with the Customer's identity) with other online betting sites, banks, credit card companies, and appropriate agencies (including law enforcement agencies).</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Cookies</div>
            <div class="article-content">
                <p>Cookies are small text files that are stored on the Customer's computer or equipment when the Customer visits certain online pages of this Website that record the Customer's preferences. The Operator uses cookies to track the Customer's use of this Website and the Internet Betting Facilities. The Operator also may use cookies to monitor traffic to this Website and the Internet Betting Facilities, improve this Website and the Internet Betting Facilities and make it easier and/or more relevant for the Customer's use.</p>
                <p>The Customer has the ability to accept or decline cookies. Most online browsers automatically accept cookies, but if the Customer prefers the Customer can usually modify the Customer's browser setting to decline cookies. To do this the Customer should consult the help menu on the Customer's browser. If the Customer chooses to decline cookies, the Customer may not be able to fully experience the interactive features of this Website and the Internet Betting Facilities.</p>
                <p>To find out more about cookies and how to decline them please visit <a href="http://www.allaboutcookies.org" target="_blank">www.allaboutcookies.org</a></p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Security</div>
            <div class="article-content">
                <p>The Operator will take all reasonable steps as required by law to ensure that the personal information the Operator collects is accurately recorded and kept securely. All personal information will be destroyed when it is no longer required to be retained by the Operator or by law.</p>
                <p>The Operator does not warrant the security of any information, which the Customer transmits to the Operator over the Internet. Any information which the Customer transmits to the Operator is transmitted at the Customer's own risk. However, once the Operator receives the Customer's transmission, the Operator will take reasonable steps to protect the Customer's personal information from misuse, loss or unauthorised access.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Internet-based Transfers</div>
            <div class="article-content">
                <p>Given that the Internet is a global environment, using the Internet to collect and process personal data necessarily involves the transmission of data on an international basis. Therefore, by browsing this Website and communicating electronically with the Operator, the Customer acknowledges and agrees to the Operator processing personal data in this way.</p>
            </div>
        </li>
    </ul>
</div>
   
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>