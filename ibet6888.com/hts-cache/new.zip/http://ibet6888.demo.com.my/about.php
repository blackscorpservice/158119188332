<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - about</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li class="cur-nav" ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li  ><a href="FAQ.php">FAQ</a></li>
                <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li  ><a href="privacy.php">Privacy Policy</a></li>
                <li  ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li class="cur-nav" ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li  ><a href="FAQ.php">FAQ</a></li>
                        <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li  ><a href="privacy.php">Privacy Policy</a></li>
                        <li  ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="content">
            <h1>About Us</h1>
            <div class="staticMain">
                <section class="provideList">
                    <h2>Provide</h2>
                    <div class="are-provide">
                        <span class="img-provide provide1"></span>
                        <h4>An intelligent and interactive entertainment platform </h4>
                    </div>
                    <div class="are-provide">
                        <span class="img-provide provide2"></span>
                        <h4>The best online gaming experience</h4>
                    </div>
                    <div class="are-provide">
                        <span class="img-provide provide3"></span>
                        <h4>State-of-the-art technology</h4>
                    </div>
                    <div class="are-provide">
                        <span class="img-provide provide4"></span>
                        <h4>Friendly, helpful and experienced customer service support</h4>
                    </div>
                    <div class="are-provide">
                        <span class="img-provide provide5"></span>
                        <h4>Safe, secure and convenient payment solutions</h4>
                    </div>
                    <div class="clearAll"></div>
                </section>
                <section class="featureList">
                    <h2>Feature</h2>
                    <ul>
                        <li class="featureLi">
                            <h3>Customer Care Excellence</h3>
                            <p>To maintain our standards as a leading international online gaming company, we have with us an extensive team of world-class gaming information experts, an friendly, helpful and experienced customer service team, marketing experts and state-of-the-art hardware and software developers to ensure that our customers are able to enjoy their online gaming activities in a safe environment. Our team also works tirelessly to ensure that the customer experience is seamless and downtime kept at a minimum.</p>
                        </li>
                        <li class="featureLi">
                            <h3>Quality Assurance</h3>
                            <p>Our team at iBET are committed to providing access to our wide range of sports betting and online entertainment options 24 hours a day, 7 days a week, 365 days a year. We believe in always putting the “customer first” and constantly refer to this motto when any changes, innovation and progress is affected.</p>
                        </li>
                        <li class="featureLi">
                            <h3>Confidentiality and System Security</h3>
                            <p>Regulations state that each customer is only allowed to have one iBET account. Therefore, security checks are performed regularly to ensure that this regulation is adhered. We use the most advanced and updated gaming software to ensure that any required calculations are performed accurately and fair. At the same time, we use an advanced encryption technology to monitor access to the iBET site 24 hours a day. iBET customers can rest assured with our safe and secure online gaming platform. </p>
                        </li>
                        <li class="featureLi">
                            <h3>Fair Play</h3>
                            <p>In order to provide a fair and conducive environment for sports betting, iBET uses the most advanced technology systems. Cooperated with our world-class gaming information expert team to ensure that all our online games meet standard regulations. In addition, our live game dealers undergo a rigorous training and selection process to ensure that the fairness and legitimacy standards of the games are upheld.
                            </p>
                        </li>
                        <li class="featureLi">
                            <h3>Payment</h3>
                            <p>iBET provides our customers with a variety of safe, secure and convenient options to deposit funds. We adhere to Know Your Customer (KYC) and Anti Money Laundering (AML) policies to ensure compliance with relevant laws and regulations of corresponding Monetary Authorities.</p>
                        </li>
                        <li class="featureLi">
                            <h3>Responsible Gaming</h3>
                            <p>iBET is committed in providing a responsible gaming experience while ensuring that our customers are enjoying the fun element of online gaming. We understand that at times, it may be difficult to control betting behavior. Therefore, we urge these customers to contact our customer service executives in order for us to provide any assistance.</p>
                        </li>
                    </ul>
                    <div class="clearAll"></div>
                </section>
            </div>
        </div>
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>