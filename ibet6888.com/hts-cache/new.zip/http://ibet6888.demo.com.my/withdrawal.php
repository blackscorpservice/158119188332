<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - withdrawal</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li  ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li class="cur-nav" ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li  ><a href="FAQ.php">FAQ</a></li>
                <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li  ><a href="privacy.php">Privacy Policy</a></li>
                <li  ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li  ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li class="cur-nav" ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li  ><a href="FAQ.php">FAQ</a></li>
                        <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li  ><a href="privacy.php">Privacy Policy</a></li>
                        <li  ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>
<div class="content">
    <h1>Withdrawal Help</h1>
    <ul class="article-list">
        <li class="article expend">
            <div class="article-title">Withdrawal</div>
            <div class="article-content" style="display: block;">
                <ul>
                    <li>The bank account holder name and the registered iBET account name must be identical to ensure successful withdrawal of funds.</li>
                    <li>iBET reserves the rights to request for identity authentication documents, such as IC or passport.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Withdrawals may be delayed under the following circumstances:</div>
            <div class="article-content">
                <ul>
                    <li>Submission of incorrect account information.</li>
                    <li>The online banking system is under maintenance.</li>
                </ul>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Withdrawal Remarks:</div>
            <div class="article-content">
                <p>Any incorrect bank details will result in delay or failure of the withdrawal.<br><span class="star">*</span>Note: Please ensure that all bank details provided are accurate.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Please avoid the following upon withdrawal submission:</div>
            <div class="article-content">
                <ul>
                    <li>Your registered bank account holder name not identical with your registered iBET account name.</li>
                    <li>Submission of invalid bank account number.</li>
                    <li>Submission of incorrect withdrawal amount.</li>
                </ul><span class="star">*</span>Note: Remember to turn off your browser’s block pop-up function
            </div>
        </li>
        <li class="article">
            <div class="article-title">Steps for withdrawal:</div>
            <div class="article-content">
                <ol type="a">
                    <li>Login to iBET website and click on [Profile].</li>
                    <li>Under ‘Account Management(iMONEY)’, click on [Credit Withdrawal].</li>
                    <li>Fill in your withdrawal amount and check that the payer’s account details are correct, then click on [Submit].</li>
                    <li>Check the withdrawal status under ‘Transaction Records’ in ‘History’ page. The status will change from ‘Withdrawal Processing’ to ‘Successful Withdrawal‘ after our Customer Service Executive successfully validates the withdrawal details provided.</li>
                </ol>
                <p><span class="star">*</span>For any further enquiries, Please Contact our Customer Service Executive via '24 Hours Live Chat'</p>
            </div>
        </li>
    </ul>
</div>
   
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>