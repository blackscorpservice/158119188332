<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - FAQ</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li  ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li class="cur-nav" ><a href="FAQ.php">FAQ</a></li>
                <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li  ><a href="privacy.php">Privacy Policy</a></li>
                <li  ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li  ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li class="cur-nav" ><a href="FAQ.php">FAQ</a></li>
                        <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li  ><a href="privacy.php">Privacy Policy</a></li>
                        <li  ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>
<div class="content">
    <h1>Frequently Asked Questions</h1>
    <ul class="article-list">
        <li class="article expend">
            <div class="article-title">How do I register on iBET?</div>
            <div class="article-content" style="display: block;">
                <p>Click "Join Now" on the landing page. Fill out the required information and click OK to complete the application.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Can I change or cancel a registered account ID?</div>
            <div class="article-content">
                <p>Details of an account cannot be changed once registered. If required, you may re-apply for a new account.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Does my login ID need to be the same as my bank account ID?</div>
            <div class="article-content">
                <p>No, your login ID does not need to be the same as your bank account ID. However, your name has to be the same as per your bank account details to ensure smooth deposit or withdrawals.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">Is my personal information secure?</div>
            <div class="article-content">
                <p>We use the best quality security measures to keep your personal information secure – Secure Socket (SSL 128 bit encryption Standard) which is safe and secure.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">What should I do if I have forgotten my password?</div>
            <div class="article-content">
                <p>Please click on "Contact Customer Service" at the bottom of our landing page to contact our customer service executives who will be able to assist.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">What is the required age to register or login to the iBET website?</div>
            <div class="article-content">
                <p>You must be at least 18 years old to register as an iBET customer.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">What should I do if the account name has been registered?</div>
            <div class="article-content">
                <p>Please click on "Contact Customer Service" at the bottom of our landing page to contact our Customer Service Executives who will be able to assist.</p>
            </div>
        </li>
        <li class="article">
            <div class="article-title">How do I activate my account?</div>
            <div class="article-content">
                <p>After logging in, please click on the “Activate Now” button. Please complete the form with accurate information, and click on “OK” to confirm and activate your account.</p>
            </div>
        </li>
    </ul>
</div>
   
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>