<!DOCTYPE html>
<html>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
    <meta name="description" content="iBET provide an intelligent and interactive entertainment platform;the best online gaming experience;State-of-the-art technology">
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1">

    <title>Sugar Bet INFO CENTER - reponsible</title>
    <link rel="icon" href="Images/favicon.ico">
    <!-- [if IE]><link rel="shortcut icon" href="Images/favicon.ico"><![endif]-->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,600,700,900">
    <link rel="stylesheet" href="Css/vendor.min.css">
    <link rel="stylesheet" href="Css/layout.min.css?v=11">
    <link rel="stylesheet" href="Css/about.css">
</head>
<body>
    <div class="wrapper">        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="deposit.php"></a>
                </li>
                <li  ><a href="about.php">About Us</a></li>
                <li  ><a href="deposit.php">Deposit Guideline/a></li>
                <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                <li  ><a href="FAQ.php">FAQ</a></li>
                <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                <li  ><a href="privacy.php">Privacy Policy</a></li>
                <li class="cur-nav" ><a href="reponsible.php">Responsible Gaming</a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <a class="logo" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div id="showbox"></div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <a class="logo-white" href="http://www.ibet.uk.com/"></a><span class="site-title">INFO CENTER</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="deposit.php"></a>
                        </li>
                        <li  ><a href="about.php">About Us</a></li>
                        <li  ><a href="deposit.php">Deposit Guideline</a></li>
                        <li  ><a href="withdrawal.php">Withdrawal Help</a></li>
                        <li  ><a href="FAQ.php">FAQ</a></li>
                        <li  ><a href="termsCondition.php">Terms of Conditions</a></li>
                        <li  ><a href="privacy.php">Privacy Policy</a></li>
                        <li class="cur-nav" ><a href="reponsible.php">Responsible Gaming</a></li>
                    </ul>
                </div>
            </div>
        </header>
<div class="content">
    <h1>Responsible Gaming</h1>
    <ul class="article-list">
        <li class="article expend">
            <div class="article-title">Responsible Gaming</div>
            <div class="article-content" style="display: block;">
                <p>iBET maintains a strong commitment to provide our customers with a responsible gambling environment. Although gambling should be enjoyed as a recreational activity, it can nevertheless also cause a problem for a minority of customers. iBET aims to prevent compulsive usage and underage access to its online games while simultaneously providing a friendly and entertaining gambling experience for its customers. As a responsible operator, the well being of the iBET’s customers is of utmost importance.</p>
                <p>Remember though that whilst gambling operators can provide tools with which an individual can control their gambling, the operator cannot assume all responsibility for exercising that control. There has to be a large element of personal responsibility.</p>
                <p>In line with that, iBET has implemented a self-exclusion function for customers who might need assistance in handling their compulsive gambling habits. Our customers may opt to self exclude themselves from having access to the Internet Betting Service or the Betting Platform for a period of either 7 days, 30 days, 90 days or for a permanent self-exclusion you may email our customer service at <a href="mailto:ibetcs.my@gmail.com">ibetcs.my@gmail.com</a> Our customers may also set their own maximum value for their wagering activity for a 7 day period for Sports, Racing and Games separately. In the Casino, our customers are able to set an amount as the Maximum Betting Loss to limit the amount that they can lose in a rolling 7 day period. Our customers can also set a daily, 7 day or 30 day deposit limit to limit the amount that can be deposited for that period. The following are a few things our customers should remember in order to keep control while gambling:</p>
                <ol>
                    <li>Gambling should not be seen as a way of making money or paying debts. It should be entertaining</li>
                    <li>Customers should familiarise themselves with the Sports Betting Rules and Games Betting Rules</li>
                    <li>Customers should only gamble the amount that they can afford to lose</li>
                    <li>Customers should not try to chase losses</li>
                    <li>Customers should keep track of the amount of money and time they have spent gambling</li>
                </ol>
                <p></p>
                <p>iBET is aware that occasional gambling might develop into a problem for customers. iBET encourages customers to consider seeking professional assistance from any of these organisations if our customers suspect that they have a gambling problem:<br><a href="http://www.gamcare.org.uk" target="_blank">http://www.gamcare.org.uk</a><br><a href="http://www.gamblingtherapy.org" target="_blank">http://www.gamblingtherapy.org</a></p>
            </div>
        </li>
    </ul>
</div>
   
</div>
<footer>
        <p>&copy; 2019 iBET.uk.com All rights reserved.</p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>
</body>
<script src="Scripts//jquery-1.10.min.js"></script>
<script src="Scripts//bundle.js"></script>

<!-- Mirrored from ibet6888.com/intl/iBET/abut/en-us/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jun 2019 14:25:10 GMT -->

</html>