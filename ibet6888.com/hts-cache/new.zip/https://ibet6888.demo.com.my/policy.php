
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=10;chrome=1">
    <meta name="description" content="Sugar Bet VIP offers you the best service and supreme enjoyment. Enter to know more information and enjoy the best offers and exclusive benefits." />
    <meta name="keywords" content="CASINO,online betting,slot," />
    <title>Sugar Bet VIP Level And Loyalty Benefits - SILVER|GOLD|PLATINUM|BLACK</title>

    <link rel="icon" href="Images/favicon.ico?v=1">
    <link rel="apple-touch-icon" href="common/img/favicon.ico">
    <!-- [if IE]>
    <link rel="shortcut icon" href="images/favicon.ico"><![endif]-->

    <link rel="stylesheet" type="text/css" href="common/plugin/bootstrap4/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="common/style/css/vendor.min.css">
    <link rel="stylesheet" type="text/css" href="common/style/css/style.css?v=1">
    <link rel="stylesheet" type="text/css" href="en-us/style/css/style.css">

</head>

<body class="page-vip" ontouchstart="">
    <div class="wrapper">
        <div class="min-nav" id="min-nav">
            <ul>
                <li>
                    <a class="home fa fa-home" href="/"></a>
                </li>
                <li class="cur-nav">
                    <a id="link-vip-mobile"> </a>
                </li>

                <li class="nav-btns-r"><a id="lnk-web-mobile" href="/">Join <span id="txt-join-mobile"></span></a></li>
            </ul>
        </div>

        <header>
            <div class="header-top">
                <div class="logo"></div><span class="site-title">VIP</span>

                <div class="time-wrap">
                    <div class="fa fa-clock-o"></div>
                    <div class="time-text" id="time-text"></div>
                </div>
            </div>

            <div class="main-nav-wrap" id="main-nav-wrap">
                <div class="btn-hamburger" id="btn-hamburger">
                    <div class="hamburger-icon"><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="logo-white"></div><span class="site-title">VIP</span>
                <div class="main-nav">
                    <ul>
                        <li>
                            <a class="home fa fa-home" href="/"></a>
                        </li>
                        <li class="cur-nav"><a id="">VIPcourtesy</a></li>

                        <li class="nav-btns-r"><a id="lnk-web" href="/">Join <span id="txt-join"></span></a></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="banner banner-vip"></div>
                <div class="content vip">
            <h1 id="title-vip" v-text="val"></h1>
            <table class="rwd table-diamond" id="">
                <thead>
                    <tr>
                        <th scope="col">Item</th>
                        <th scope="col">Normal</th>
                        <th scope="col">Silver</th>
                        <th scope="col">Gold</th>
                        <th scope="col">Platinum</th>
                        <th scope="col">Black</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td aria-label="Item">
                            <div>Live Casino Rebate Bonus</div>
                        </td>
                        <td aria-label="Normal">
                            <div>0.75%</div>
                        </td>
                        <td aria-label="Silver">
                            <div>0.75%</div>
                        </td>
                        <td aria-label="Gold">
                            <div>0.75%</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>0.75%</div>
                        </td>
                        <td aria-label="Black">
                            <div>0.75%</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Slot Game Rebate Bonus</div>
                        </td>
                        <td aria-label="Normal">
                            <div>0.50%</div>
                        </td>
                        <td aria-label="Silver">
                            <div>0.60%</div>
                        </td>
                        <td aria-label="Gold">
                            <div>0.70%</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>0.80%</div>
                        </td>
                        <td aria-label="Black">
                            <div>1.00%</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Lottery Rebate Bonus</div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Platinum">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Black">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Sportsbook Rebate bonus</div>
                        </td>
                        <td aria-label="Normal">
                            <div>0.35%</div>
                        </td>
                        <td aria-label="Silver">
                            <div>0.35%</div>
                        </td>
                        <td aria-label="Gold">
                            <div>0.35%</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>0.35%</div>
                        </td>
                        <td aria-label="Black">
                            <div>0.35%</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Advancement Condition</div>
                        </td>
                        <td aria-label="Normal">
                            <div>Manual verify</div>
                        </td>
                        <td aria-label="Silver">
                            <div>Accumulate deposit of RM500 and above within a single day</div>
                        </td>
                        <td aria-label="Gold">
                            <div>Accumulate deposit of RM5,000 and above within a single day</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>Accumulate deposit of RM10,000 and above within a single day</div>
                        </td>
                        <td aria-label="Black">
                            <div>Accumulate deposit of RM30,000 and above within a single day</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Membership Level Maintain</div>
                        </td>
                        <td aria-label="Normal">
                            <div>Manual verify</div>
                        </td>
                        <td aria-label="Silver">
                            <div>Manual verify</div>
                        </td>
                        <td aria-label="Gold">
                            <div>Accumulate 400,000 effective rollover amount (Per Season)
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Platinum">
                            <div>Accumulate 800,000 effective rollover amount (Per Season)
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Black">
                            <div>Accumulate 2,400,000 effective rollover amount (Per Season)
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>iPOINT</div>
                        </td>
                        <td aria-label="Normal">
                            <div>Accumulated 200 rollover amount = 1 iPOINT (Lottery not included)</div>
                        </td>
                        <td aria-label="Silver">
                            <div>Accumulated 190 rollover amount = 1 iPOINT (Lottery not included)</div>
                        </td>
                        <td aria-label="Gold">
                            <div>Accumulated 180 rollover amount = 1 iPOINT (Lottery not included)</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>Accumulated 170 rollover amount = 1 iPOINT (Lottery not included)</div>
                        </td>
                        <td aria-label="Black">
                            <div>Accumulated 160 rollover amount = 1 iPOINT (Lottery not included)</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Upgrade Bonus
                                <div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Each membership level upgrade reward is limited to a one-time claim only.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div>RM388, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Platinum">
                            <div>RM588, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Black">
                            <div>RM888, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Birthday Bonus</div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div>RM18, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Gold">
                            <div>RM388, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Platinum">
                            <div>RM588, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Black">
                            <div>RM888, 6 times rollover
                                <div class="fai fai-info fai-blue hidden-content">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Occasional Festive gifts
                                <div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">
                                    <div class="im-popover">
                                        <div class="im-popover-arrow"></div>
                                        <div class="im-popover-content">
                                            Giving away the latest 3C products, such as smartphones, iPAD, Luxury product, etc. Very attractive gifts that meets all your needs!
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                        <td aria-label="Platinum">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                        <td aria-label="Black">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Priority of Deposit/Wirthdrawal</div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Platinum">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                        <td aria-label="Black">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Withdrawal Limit</div>
                        </td>
                        <td aria-label="Normal">
                            <div>Daily RM100,000</div>
                        </td>
                        <td aria-label="Silver">
                            <div>Daily RM500,000</div>
                        </td>
                        <td aria-label="Gold">
                            <div>Daily RM2,000,000</div>
                        </td>
                        <td aria-label="Platinum">
                            <div>Daily RM2,000,000</div>
                        </td>
                        <td aria-label="Black">
                            <div>Daily RM2,000,000</div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Exclusive Customer Service</div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Platinum">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                        <td aria-label="Black">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                    </tr>
                    <tr>
                        <td aria-label="Item">
                            <div>Casino Visit Tour</div>
                        </td>
                        <td aria-label="Normal">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Silver">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Gold">
                            <div><i class="fa fa-times text-danger"></i></div>
                        </td>
                        <td aria-label="Platinum">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                        <td aria-label="Black">
                            <div><i class="fa fa-check text-success"></i></div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="description">
                <h3>《Preferential rules》</h3>
                <ul class="ul-rule">
                    <li><span class="txt-bold">Advancement condition</span> : System determine automatically，promotion coupons will be delivered immediately once upgrade completed .</li>
                    <li><span class="txt-bold">Maintaining level condition</span> : System automatically accumulate effective rollover to determine whether the designated effective rollover has been met, accumulate start count after the upgraded month next month as the first month and so on<br>
                        <span class="txt-blue">Example :</span> Member upgrade to be a silver card member at <sup>3rd</sup> January, system accumulated time are <span class="txt-bold">1<sup>st</sup></span> February time <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">30<sup>th</sup></span> April <span class="txt-bold">23:59:59</span> (GMT+8) stopped accumulate, period of 3 months (<span class="txt-blue">1 season</span>) to accumulate maintaining level conditions.
                    </li>
                    <li>
                        <span class="txt-bold">iPOINT :</span> Will be issued by the players themselves / system settlement<br>
                        <span class="txt-blue">Example :</span> Normal member in <span class="txt-bold">3<sup>rd</sup></span> January placed bets, total effective rollover are 700.<br> Member issued the current effective rollover settlement themselves as 250, unable to receive iPOINT ( due to not met the minimum requirement of 350 effective rollover = 1 iPOINT ), the next time calculations of effective rollover by system reach 450, system will be issue an 2 iPOINT to member :<br>
                        <div class="rulebox">
                            Minimum requirement : 350 effective rollover = 1 iPOINT<br> Previous 250 effective rollover<br> Second calculations effective rollover : 450 *2 iPOINT ( the additional 100 will be combine with previous 250 = 350 )<br>
                        </div>
                        <span class="txt-red">xHave to be within a season period</span>

                    </li>
                    <li><span class="txt-bold">Free Chip Coupons :</span> will be automatically distributed at <span class="txt-bold">00:00:00</span> (GMT+8) first day of the month, 1 month validity, the unused free chip coupons will be revoke on the next month.
                        <span class="txt-blue">Example :</span> 1<sup>st</sup> January distributed free chips coupon have to be used before 31st January 23:59:59 (GMT+8)
                    </li>
                    <li><span class="txt-bold">Withdrawal rolling :</span> Daily accumulated time start from the same day <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">23:59:59</span> (GMT+8), system will automatically clear the settlement amount of withdrawal rolling on daily <span class="txt-bold">12:00:00</span> (GMT+8) if member did not make the settlement a day before and will be distributed at <span class="txt-bold">18:00:00</span> (GMT+8) on the same day. (Sportsbook based on US EAST TIME (BEIJING TIME – 12 Hours), will be based on payout settlement time.)<br>
                        <span class="txt-blue">Example :</span> <span class="txt-bold">4<sup>th</sup></span> January <span class="txt-bold">12:00:00</span> (GMT+8) system started automatically begin settlement if member did not make the settlement for 3<sup>rd</sup> January withdrawal rolling and will be distributed at the same day at <span class="txt-bold">18:00:00</span> (GMT+8)
                    </li>
                    <li>
                        <span class="txt-bold">List of games which are unable to enjoy the rebate bonus</span><br> 『
                        <span class="txt-bold">Live Casino</span>』All Live casino Blackjack<br> 『
                        <span class="txt-bold">Slot Games</span>』Video poker, Table games, Fishing Games available in all video galleries<br> 『
                        <span class="txt-bold">Lottery</span>』Yun gu hall, GB game room and all bets from KENO, LOTTERY<br> 『
                        <span class="txt-bold">Sportsbook</span>』All invalid, tie, canceled, both side betting (Against betting odds ) and any bets below 1.70 (European Odds) odds (Malay odds 0.70; Hong Kong odds 0.70; Indonesian odds -1.20; U.S. -120) and non-sports will not be counted in the valid bet. (Greyhound race, Number game/Keno and other rebates are not included).
                    </li>
                </ul>
                <h3>《Coupon Instructions》</h3>
                <ul class="ul-use">
                    <li><span class="txt-blue">Step1.</span> Successfully login member account, click「<span class="txt-red txt-bold">Coupon</span>」at the top, system will redirected the screen , click 「<span class="txt-red txt-bold">Redeem</span>」</li>

                    <li><span class="txt-blue">Step2.</span> According to the instructions on the page，select the favor betting game room、total，enter completed and system will display the transfer amount and bonus which has been transferred successfully into the game room with the required rollover </li>

                    <li><span class="txt-blue">Step3.</span> Confirm the application and click on「<span class="txt-red txt-bold">OK</span>」button on below, system will be automatically transfer and bind the amount with bonus into the selected transferred game room</li>

                    <li><span class="txt-blue">Step4.</span>Completed betting amount / Withdrawal request，you must first go to the「<span class="txt-red txt-bold">self-promotion</span>」→ 「<span class="txt-red txt-bold">Unlock</span>」，select the game room to be unlocked to submit request，until the system approved，may re-deposited in the game room to bets/ make withdrawal</li>

                </ul>

                <h3>《Promotion Terms &amp; Conditions》</h3>
                <ul class="ul-rule">
                    <li>Promotions are for entertainment purposes only, if founded that the user has more than one account, including same name, same email address, same/similar ip address, same home address, same bank account, same computer and so on with abnormal betting behavior, once discovered, <span class="txt-bold">Sugar Bet</span> will retain the right to freeze your account along with profit and balance.
                    </li>
                    <li>Any opposite bets, tie, any hedging betting (cross-site opposite bets) rejected bets, invalid bets, draw or any sports odds less than 1.5 are not counted as required valid bets amount.</li>
                    <li>Any betting done by through third-party illegal software such as 「robot」and 「Open Double / Multiple Windows」may be considered as illegal betting. <span class="txt-bold">Sugar Bet</span> reserves the right to freeze the balance of the suspected account and close the member account.</li>
                    <li><span class="txt-bold">Sugar Bet</span> reserves the right to check all members' betting records and reserves the right to suspend, cancel or claim back all offers any time if a member breaches the rules and regulations of the event or has any non-entertainment use for profit-making.</li>
                    <li>If the account is suspected of being abusive and / or not eligible for the promotion, <span class="txt-bold">Sugar Bet</span> reserves the right to ask the member to submit relevant supporting documents to verify for identity verification.</li>
                    <li>Any individual / team / organization suspected of using dishonest means or fraud for the purpose to cheat/ abuse of bonus, once verified, <span class="txt-bold">Sugar Bet</span> reserves the right to freeze the relevant account profits and balances.</li>
                    <li>By participating in this offer, you are agreeing to the Terms and Conditions of Offer.</li>
                    <li><span class="txt-bold">Sugar Bet</span> reserves the right to amend, terminate or the final interpretation of this promotion and to change this event without any prior notice.</li>
                    <li>If found illegal betting situation, shall freeze the deposit (including the amount of profit and bonus), the system will automatically clear the balance to zero (0)</li>
                </ul>
            </div>
        </div>

            </div>

    
    <footer>
        <div class="footer-btns-wrap">
            <a id="lnk-web-footer" href="/">Go to <span id="txt-go"></span></a>
            <a class="js-launch-join-wechat" href="javascript:;">Add <span id="txt-add-app"></span></a>
        </div>
        <p id="txt-copyright"></p>
        <p>For the best viewing experience, upgrade your web browser to Google Chrome, Mozilla Firefox or Internet Explorer 9 and above.</p>
    </footer>

        <!--
    <div class="join-wechat-wrap" id="join-wechat-wrap">
        <div class="join-wechat-title"><span id="title-app"></span> customer service, Always at your service!</div>
        <div class="img-joinwechat"></div>
    </div>-->
</body>

</html>
<script src="common/plugin/vue.min.js"></script>
<script src="common/plugin/jquery-2.1.4.min.js"></script>
<script src="common/plugin/w3.js"></script>
<script src="common/plugin/jquery.colorbox-min.js"></script>
<script src="common/plugin/monent/monent-with-locales.min.js"></script>

<script src="common/js/helper/uri.js"></script>
<script src="common/js/app.min.js?v=2"></script>

<script>
    // favicon文字
    if(window.localStorage["syscode"] == 'my'){
        document.title = 'iBET VIP Level And Loyalty Benefits - SILVER|GOLD|PLATINUM|BLACK'
    }

    if(window.localStorage["syscode"] == 'cn'){
        document.title = '愛博 VIP'
    }

    if(window.localStorage["syscode"] == 'th'){
        document.title = 'TBet VIP'
    }
    if(window.localStorage["syscode"] == 'hl8'){
        document.title = 'HL8 VIP Level And Loyalty Benefits - SILVER|GOLD|PLATINUM|BLACK'
    }

    $('body').addClass('syscode-' + window.localStorage["syscode"]);


    var slogandata = {
        cn:
            '',//中國沒有英文版
        my:
            'The best VIP courtesy, the highest enjoyment!',
        th:
            'The best VIP courtesy, the highest enjoyment!',
    };

    var titleData = [
        'Item',
        'Normal',
        'Silver',
        'Gold',
        'Platinum',
        'Black',
        'Diamond'
    ];
    var ruleData = {
        cn: [
            //中國沒有英文版
        ],
        my: [
            ['Live Casino Rebate Bonus', '0.75%', '0.75%', '0.75%', '0.75%', '0.75%'],
            ['Slot Game Rebate Bonus', '0.50%', '0.60%', '0.70%', '0.80%', '1.00%'],
            ['Lottery Rebate Bonus', '✘', '✘', '✘', '✘', '✘'],
            ['Sportsbook Rebate bonus', '0.35%', '0.35%', '0.35%', '0.35%', '0.35%'],
            [
                'Advancement Condition',
                'Manual verify',
                'Accumulate deposit of RM500 and above within a single day',
                'Accumulate deposit of RM5,000 and above within a single day',
                'Accumulate deposit of RM10,000 and above within a single day',
                'Accumulate deposit of RM30,000 and above within a single day'
            ],
            [
                'Membership Level Maintain',
                'Manual verify',
                'Manual verify',
                `Accumulate 400,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
                `Accumulate 800,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
                `Accumulate 2,400,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
            ],

            [
                'iPOINT',
                'Accumulated 200 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 190 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 180 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 170 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 160 rollover amount = 1 iPOINT (Lottery not included)',
            ],

            [
                'Upgrade Bonus<div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">\n' +
                '<div class="im-popover">\n' +
                '<div class="im-popover-arrow"></div>\n' +
                '<div class="im-popover-content">\n' +
                'Each membership level upgrade reward is limited to a one-time claim only.\n' +
                '</div>\n' +
                '</div>\n' +
                '</div>',
                '✘', '✘',
                `RM388, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                               Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `RM588, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `RM888, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
            ],

            [
                'Birthday Bonus',
                '✘',
                `RM18, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM388, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM588, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM888, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,
            ],

            ['Occasional Festive gifts<div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">\n' +
            '<div class="im-popover">\n' +
            '<div class="im-popover-arrow"></div>\n' +
            '<div class="im-popover-content">\n' +
            'Giving away the latest 3C products, such as smartphones, iPAD, Luxury product, etc. Very attractive gifts that meets all your needs!\n                                ' +
            '</div>\n' +
            '</div>\n' +
            '</div>', '✘', '✘', '✔', '✔', '✔'],
            ['Priority of Deposit/Wirthdrawal', '✘', '✘', '✘', '✔', '✔'],
            ['Withdrawal Limit', 'Daily RM100,000', 'Daily RM500,000', 'Daily RM2,000,000', 'Daily RM2,000,000', 'Daily RM2,000,000'],
            ['Exclusive Customer Service', '✘', '✘', '✘', '✔', '✔'],
            ['Casino Visit Tour', '✘', '✘', '✘', '✔', '✔'],
        ],
        hl8: [
            ['Live Casino Rebate Bonus', '0.75%', '0.75%', '0.75%', '0.75%', '0.75%'],
            ['Slot Game Rebate Bonus', '0.50%', '0.60%', '0.70%', '0.80%', '1.00%'],
            ['Lottery Rebate Bonus', '✘', '✘', '✘', '✘', '✘'],
            ['Sportsbook Rebate bonus', '0.35%', '0.35%', '0.35%', '0.35%', '0.35%'],
            [
                'Advancement Condition',
                'Manual verify',
                'Accumulate deposit of RM500 and above within a single day',
                'Accumulate deposit of RM5,000 and above within a single day',
                'Accumulate deposit of RM10,000 and above within a single day',
                'Accumulate deposit of RM30,000 and above within a single day'
            ],
            [
                'Membership Level Maintain',
                'Manual verify',
                'Manual verify',
                `Accumulate 400,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
                `Accumulate 800,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
                `Accumulate 2,400,000 effective rollover amount (Per Season)
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Advanced level of the month ※The next month after the upgraded level of member begins the first month calculations for specific level conditions of membership level maintain, the cutoff date of the effective rollover amount are the last day of the third month 23:59:59, and the first (1) day of the new month 16:00 starts the accumulative of rollover amount with member level updates
                                </div>
                            </div>
                        </div>`,
            ],

            [
                'iPOINT',
                'Accumulated 200 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 190 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 180 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 170 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 160 rollover amount = 1 iPOINT (Lottery not included)',
            ],

            [
                'Upgrade Bonus<div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">\n' +
                '<div class="im-popover">\n' +
                '<div class="im-popover-arrow"></div>\n' +
                '<div class="im-popover-content">\n' +
                'Each membership level upgrade reward is limited to a one-time claim only.\n' +
                '</div>\n' +
                '</div>\n' +
                '</div>',
                '✘', '✘',
                `RM388, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                               Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `RM588, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `RM888, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
            ],

            [
                'Birthday Bonus',
                '✘',
                `RM18, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM388, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM588, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `RM888, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,
            ],

            ['Occasional Festive gifts<div class="fai fai-info fai-blue hidden-content d-inline-block ml-1">\n' +
            '<div class="im-popover">\n' +
            '<div class="im-popover-arrow"></div>\n' +
            '<div class="im-popover-content">\n' +
            'Giving away the latest 3C products, such as smartphones, iPAD, Luxury product, etc. Very attractive gifts that meets all your needs!\n                                ' +
            '</div>\n' +
            '</div>\n' +
            '</div>', '✘', '✘', '✔', '✔', '✔'],
            ['Priority of Deposit/Wirthdrawal', '✘', '✘', '✘', '✔', '✔'],
            ['Withdrawal Limit', 'Daily RM100,000', 'Daily RM500,000', 'Daily RM2,000,000', 'Daily RM2,000,000', 'Daily RM2,000,000'],
            ['Exclusive Customer Service', '✘', '✘', '✘', '✔', '✔'],
            ['Casino Visit Tour', '✘', '✘', '✘', '✔', '✔'],
        ],
        th: [
            ['Live Casino Rebate Bonus', '✘', '0.10%', '0.30%', '0.50%', '0.75%'],
            ['Slot Game Rebate Bonus', '✘', '✘', '✘', '✘', '✘'],
            ['Lottery Rebate Bonus', '✘', '✘', '✘', '✘', '✘'],
            ['Sportsbook Rebate bonus', '✘', '✘', '0.10%', '0.20%', '0.35%'],
            [
                'Advancement Condition',
                'Manual verify',
                'Accumulate 150,000 effective rollover amount(Per week)',
                'Accumulate 500,000 effective rollover amount(Per week)',
                'Accumulate 1,000,000 effective rollover amount(Per week)',
                'Accumulate 2,000,000 effective rollover amount(Per week)'
            ],
            [
                'Membership Level Maintain',
                'Manual verify',
                'Accumulate 450,000 effective rollover amount(Per season)',
                `Accumulate 1,500,000 effective rollover amount(Per season)`,
                `Accumulate 3,000,000 effective rollover amount(Per season)`,
                `Accumulate 6,000,000 effective rollover amount(Per season)`,
            ],

            [
                'iPOINT',
                'Accumulated 200 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 190 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 180 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 170 rollover amount = 1 iPOINT (Lottery not included)',
                'Accumulated 160 rollover amount = 1 iPOINT (Lottery not included)',
            ],

            [
                'Upgrade Bonus',
                '✘', '✘',
                `500B, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                               Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `1000B, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
                `2000B, 6 times rollover
                    <div class="fai fai-info fai-blue hidden-content">
                        <div class="im-popover">
                            <div class="im-popover-arrow"></div>
                            <div class="im-popover-content">
                                Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                            </div>
                        </div>
                    </div>`,
            ],

            [
                'Birthday Bonus',
                '✘',
                `168B, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `688B, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `1688B, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,

                `2688B, 6 times rollover
                        <div class="fai fai-info fai-blue hidden-content">
                            <div class="im-popover">
                                <div class="im-popover-arrow"></div>
                                <div class="im-popover-content">
                                    Member will be receive a coupon, by using system transfer feature, select the coupon and follow the instructions to claim the bonus.
                                </div>
                            </div>
                        </div>`,
            ],

            ['Occasional Festive gifts', '✘', '✘', '✔', '✔', '✔'],
            ['Priority of Deposit/Wirthdrawal', '✘', '✘', '✔', '✔', '✔'],
            ['Withdrawal Limit', 'Daily 1,000,000 Bath', 'Daily 5,000,000 Bath', 'Daily 20,000,000 Bath', 'Daily 20,000,000 Bath', 'Daily 20,000,000 Bath'],
            ['Exclusive Customer Service', '✘', '✘', '✘', '✔', '✔'],
        ],
    };
    var descriptionData = {
        cn: ``
        ,
        my: `
              <h3>《Preferential rules》</h3>
              <ul class="ul-rule">
                  <li><span class="txt-bold">Advancement condition</span> : System determine automatically，promotion coupons will be delivered immediately once upgrade completed .</li>
                  <li><span class="txt-bold">Maintaining level condition</span> : System automatically accumulate effective rollover to determine whether the designated effective rollover has been met, accumulate start count after the upgraded month next month as the first month and so on<br/>
                      <span class="txt-blue">Example :</span> Member upgrade to be a silver card member at <sup>3rd</sup> January, system accumulated time are <span class="txt-bold">1<sup>st</sup></span> February time <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">30<sup>th</sup></span> April <span class="txt-bold">23:59:59</span> (GMT+8) stopped accumulate, period of 3 months (<span class="txt-blue">1 season</span>) to accumulate maintaining level conditions.
                  </li>
                  <li>
                      <span class="txt-bold">iPOINT :</span> Will be issued by the players themselves / system settlement<br/>
                      <span class="txt-blue">Example :</span> Normal member in <span class="txt-bold">3<sup>rd</sup></span> January placed bets, total effective rollover are 700.<br/>
                          Member issued the current effective rollover settlement themselves as 250, unable to receive iPOINT ( due to not met the minimum requirement of 350 effective rollover = 1 iPOINT ), the next time calculations of effective rollover by system reach 450, system will be issue an 2 iPOINT to member :<br>
                      <div class="rulebox">
                          Minimum requirement : 350 effective rollover = 1 iPOINT<br>
                          Previous 250 effective rollover<br>
                          Second calculations effective rollover : 450 *2 iPOINT ( the additional 100 will be combine with previous 250 = 350 )<br>
                      </div>
                      <span class="txt-red">xHave to be within a season period</span>

                  </li>
                  <li><span class="txt-bold">Free Chip Coupons :</span> will be automatically distributed at <span class="txt-bold">00:00:00</span> (GMT+8) first day of the month, 1 month validity, the unused free chip coupons will be revoke on the next month.
                      <span class="txt-blue">Example :</span> 1<sup>st</sup> January distributed free chips coupon have to be used before 31st January 23:59:59 (GMT+8)
                  </li>
                  <li><span class="txt-bold">Withdrawal rolling :</span> Daily accumulated time start from the same day <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">23:59:59</span> (GMT+8), system will automatically clear the settlement amount of withdrawal rolling on daily <span class="txt-bold">12:00:00</span> (GMT+8) if member did not make the settlement a day before and will be distributed at <span class="txt-bold">18:00:00</span> (GMT+8) on the same day. (Sportsbook based on US EAST TIME (BEIJING TIME – 12 Hours), will be based on payout settlement time.)<br/>
                      <span class="txt-blue">Example :</span> <span class="txt-bold">4<sup>th</sup></span> January <span class="txt-bold">12:00:00</span> (GMT+8) system started automatically begin settlement if member did not make the settlement for 3<sup>rd</sup> January withdrawal rolling and will be distributed at the same day at <span class="txt-bold">18:00:00</span> (GMT+8)
                  </li>
                  <li>
                      <span class="txt-bold">List of games which are unable to enjoy the rebate bonus</span><br/>
                      『<span class="txt-bold">Live Casino</span>』All Live casino Blackjack<br/>
                      『<span class="txt-bold">Slot Games</span>』Video poker, Table games, Fishing Games available in all video galleries<br/>
                      『<span class="txt-bold">Lottery</span>』Yun gu hall, GB game room and all bets from KENO, LOTTERY<br/>
                      『<span class="txt-bold">Sportsbook</span>』All invalid, tie, canceled, both side betting (Against betting odds ) and any bets below 1.70 (European Odds) odds (Malay odds 0.70; Hong Kong odds 0.70; Indonesian odds -1.20; U.S. -120) and non-sports will not be counted in the valid bet. (Greyhound race, Number game/Keno and other rebates are not included).
                  </li>
              </ul>
              <h3>《Coupon Instructions》</h3>
              <ul class="ul-use">
                  <li><span class="txt-blue">Step1.</span> Successfully login member account, click「<span class="txt-red txt-bold">Coupon</span>」at the top, system will redirected the screen , click 「<span class="txt-red txt-bold">Redeem</span>」</li>

                  <li><span class="txt-blue">Step2.</span> According to the instructions on the page，select the favor betting game room、total，enter completed and system will display the transfer amount and bonus which has been transferred successfully into the game room with the required rollover	</li>

                  <li><span class="txt-blue">Step3.</span> Confirm the application and click on「<span class="txt-red txt-bold">OK</span>」button on below, system will be automatically transfer and bind the amount with bonus into the selected transferred game room</li>

                  <li><span class="txt-blue">Step4.</span>Completed betting amount / Withdrawal request，you must first go to the「<span class="txt-red txt-bold">self-promotion</span>」→ 「<span class="txt-red txt-bold">Unlock</span>」，select the game room to be unlocked to submit request，until the system approved，may re-deposited in the game room to bets/ make withdrawal</li>

              </ul>

              <h3>《Promotion Terms & Conditions》</h3>
              <ul class="ul-rule">
                  <li>Promotions are for entertainment purposes only, if founded that the user has more than one account, including same name, same email address, same/similar ip address, same home address, same bank account, same computer and so on with abnormal betting behavior, once discovered, <span class="txt-bold">Sugar Bet</span> will retain the right to freeze your account along with profit and balance.
                  </li>
                  <li>Any opposite bets, tie, any hedging betting (cross-site opposite bets) rejected bets, invalid bets, draw or any sports odds less than 1.5 are not counted as required valid bets amount.</li>
                  <li>Any betting done by through third-party illegal software such as 「robot」and 「Open Double / Multiple Windows」may be considered as illegal betting. <span class="txt-bold">Sugar Bet</span> reserves the right to freeze the balance of the suspected account and close the member account.</li>
                  <li><span class="txt-bold">Sugar Bet</span> reserves the right to check all members' betting records and reserves the right to suspend, cancel or claim back all offers any time if a member breaches the rules and regulations of the event or has any non-entertainment use for profit-making.</li>
                  <li>If the account is suspected of being abusive and / or not eligible for the promotion, <span class="txt-bold">Sugar Bet</span> reserves the right to ask the member to submit relevant supporting documents to verify for identity verification.</li>
                  <li>Any individual / team / organization suspected of using dishonest means or fraud for the purpose to cheat/ abuse of bonus, once verified, <span class="txt-bold">Sugar Bet</span> reserves the right to freeze the relevant account profits and balances.</li>
                  <li>By participating in this offer, you are agreeing to the Terms and Conditions of Offer.</li>
                  <li><span class="txt-bold">Sugar Bet</span> reserves the right to amend, terminate or the final interpretation of this promotion and to change this event without any prior notice.</li>
                  <li>If found illegal betting situation, shall freeze the deposit (including the amount of profit and bonus), the system will automatically clear the balance to zero (0)</li>
              </ul>
            `
        ,

        hl8: `
              <h3>《Preferential rules》</h3>
              <ul class="ul-rule">
                  <li><span class="txt-bold">Advancement condition</span> : System determine automatically，promotion coupons will be delivered immediately once upgrade completed .</li>
                  <li><span class="txt-bold">Maintaining level condition</span> : System automatically accumulate effective rollover to determine whether the designated effective rollover has been met, accumulate start count after the upgraded month next month as the first month and so on<br/>
                      <span class="txt-blue">Example :</span> Member upgrade to be a silver card member at <sup>3rd</sup> January, system accumulated time are <span class="txt-bold">1<sup>st</sup></span> February time <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">30<sup>th</sup></span> April <span class="txt-bold">23:59:59</span> (GMT+8) stopped accumulate, period of 3 months (<span class="txt-blue">1 season</span>) to accumulate maintaining level conditions.
                  </li>
                  <li>
                      <span class="txt-bold">iPOINT :</span> Will be issued by the players themselves / system settlement<br/>
                      <span class="txt-blue">Example :</span> Normal member in <span class="txt-bold">3<sup>rd</sup></span> January placed bets, total effective rollover are 700.<br/>
                          Member issued the current effective rollover settlement themselves as 250, unable to receive iPOINT ( due to not met the minimum requirement of 350 effective rollover = 1 iPOINT ), the next time calculations of effective rollover by system reach 450, system will be issue an 2 iPOINT to member :<br>
                      <div class="rulebox">
                          Minimum requirement : 350 effective rollover = 1 iPOINT<br>
                          Previous 250 effective rollover<br>
                          Second calculations effective rollover : 450 *2 iPOINT ( the additional 100 will be combine with previous 250 = 350 )<br>
                      </div>
                      <span class="txt-red">xHave to be within a season period</span>

                  </li>
                  <li><span class="txt-bold">Free Chip Coupons :</span> will be automatically distributed at <span class="txt-bold">00:00:00</span> (GMT+8) first day of the month, 1 month validity, the unused free chip coupons will be revoke on the next month.
                      <span class="txt-blue">Example :</span> 1<sup>st</sup> January distributed free chips coupon have to be used before 31st January 23:59:59 (GMT+8)
                  </li>
                  <li><span class="txt-bold">Withdrawal rolling :</span> Daily accumulated time start from the same day <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">23:59:59</span> (GMT+8), system will automatically clear the settlement amount of withdrawal rolling on daily <span class="txt-bold">12:00:00</span> (GMT+8) if member did not make the settlement a day before and will be distributed at <span class="txt-bold">18:00:00</span> (GMT+8) on the same day. (Sportsbook based on US EAST TIME (BEIJING TIME – 12 Hours), will be based on payout settlement time.)<br/>
                      <span class="txt-blue">Example :</span> <span class="txt-bold">4<sup>th</sup></span> January <span class="txt-bold">12:00:00</span> (GMT+8) system started automatically begin settlement if member did not make the settlement for 3<sup>rd</sup> January withdrawal rolling and will be distributed at the same day at <span class="txt-bold">18:00:00</span> (GMT+8)
                  </li>
                  <li>
                      <span class="txt-bold">List of games which are unable to enjoy the rebate bonus</span><br/>
                      『<span class="txt-bold">Live Casino</span>』All Live casino Blackjack<br/>
                      『<span class="txt-bold">Slot Games</span>』Video poker, Table games, Fishing Games available in all video galleries<br/>
                      『<span class="txt-bold">Lottery</span>』Yun gu hall, GB game room and all bets from KENO, LOTTERY<br/>
                      『<span class="txt-bold">Sportsbook</span>』All invalid, tie, canceled, both side betting (Against betting odds ) and any bets below 1.70 (European Odds) odds (Malay odds 0.70; Hong Kong odds 0.70; Indonesian odds -1.20; U.S. -120) and non-sports will not be counted in the valid bet. (Greyhound race, Number game/Keno and other rebates are not included).
                  </li>
              </ul>
              <!--<h3>《Coupon Instructions》</h3>
              <ul class="ul-use">
                  <li><span class="txt-blue">Step1.</span> Successfully login member account, click「<span class="txt-red txt-bold">Coupon</span>」at the top, system will redirected the screen , click 「<span class="txt-red txt-bold">Redeem</span>」</li>

                  <li><span class="txt-blue">Step2.</span> According to the instructions on the page，select the favor betting game room、total，enter completed and system will display the transfer amount and bonus which has been transferred successfully into the game room with the required rollover	</li>

                  <li><span class="txt-blue">Step3.</span> Confirm the application and click on「<span class="txt-red txt-bold">OK</span>」button on below, system will be automatically transfer and bind the amount with bonus into the selected transferred game room</li>

                  <li><span class="txt-blue">Step4.</span>Completed betting amount / Withdrawal request，you must first go to the「<span class="txt-red txt-bold">self-promotion</span>」→ 「<span class="txt-red txt-bold">Unlock</span>」，select the game room to be unlocked to submit request，until the system approved，may re-deposited in the game room to bets/ make withdrawal</li>

              </ul>-->

              <h3>《Promotion Terms & Conditions》</h3>
              <ul class="ul-rule">
                  <li>Promotions are for entertainment purposes only, if founded that the user has more than one account, including same name, same email address, same/similar ip address, same home address, same bank account, same computer and so on with abnormal betting behavior, once discovered, <span class="txt-bold">HL8</span> will retain the right to freeze your account along with profit and balance.
                  </li>
                  <li>Any opposite bets, tie, any hedging betting (cross-site opposite bets) rejected bets, invalid bets, draw or any sports odds less than 1.5 are not counted as required valid bets amount.</li>
                  <li>Any betting done by through third-party illegal software such as 「robot」and 「Open Double / Multiple Windows」may be considered as illegal betting. <span class="txt-bold">HL8</span> reserves the right to freeze the balance of the suspected account and close the member account.</li>
                  <li><span class="txt-bold">HL8</span> reserves the right to check all members' betting records and reserves the right to suspend, cancel or claim back all offers any time if a member breaches the rules and regulations of the event or has any non-entertainment use for profit-making.</li>
                  <li>If the account is suspected of being abusive and / or not eligible for the promotion, <span class="txt-bold">HL8</span> reserves the right to ask the member to submit relevant supporting documents to verify for identity verification.</li>
                  <li>Any individual / team / organization suspected of using dishonest means or fraud for the purpose to cheat/ abuse of bonus, once verified, <span class="txt-bold">HL8</span> reserves the right to freeze the relevant account profits and balances.</li>
                  <li>By participating in this offer, you are agreeing to the Terms and Conditions of Offer.</li>
                  <li><span class="txt-bold">HL8</span> reserves the right to amend, terminate or the final interpretation of this promotion and to change this event without any prior notice.</li>
                  <li>If found illegal betting situation, shall freeze the deposit (including the amount of profit and bonus), the system will automatically clear the balance to zero (0)</li>
              </ul>
            `


        ,
        th: `
              <h3>《Preferential rules》</h3>
              <ul class="ul-rule">
                  <li><span class="txt-bold">Advancement condition</span> : System determine automatically，promotion coupons will be delivered immediately once upgrade completed .</li>
                  <li><span class="txt-bold">Maintaining level condition</span> : System automatically accumulate effective rollover to determine whether the designated effective rollover has been met, accumulate start count after the upgraded month next month as the first month and so on<br/>
                      <span class="txt-blue">Example :</span> Member upgrade to be a silver card member at <sup>3rd</sup> January, system accumulated time are <span class="txt-bold">1<sup>st</sup></span> February time <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">30<sup>th</sup></span> April <span class="txt-bold">23:59:59</span> (GMT+8) stopped accumulate, period of 3 months (<span class="txt-blue">1 season</span>) to accumulate maintaining level conditions.
                  </li>
                  <li>
                      <span class="txt-bold">iPOINT :</span> Will be issued by the players themselves / system settlement<br/>
                      <span class="txt-blue">Example :</span> Normal member in <span class="txt-bold">3<sup>rd</sup></span> January placed bets, total effective rollover are 700.<br/>
                          Member issued the current effective rollover settlement themselves as 250, unable to receive iPOINT ( due to not met the minimum requirement of 350 effective rollover = 1 iPOINT ), the next time calculations of effective rollover by system reach 450, system will be issue an 2 iPOINT to member :<br>
                      <div class="rulebox">
                          Minimum requirement : 350 effective rollover = 1 iPOINT<br>
                          Previous 250 effective rollover<br>
                          Second calculations effective rollover : 450 *2 iPOINT ( the additional 100 will be combine with previous 250 = 350 )<br>
                      </div>
                      <span class="txt-red">xHave to be within a season period</span>

                  </li>
                  <li><span class="txt-bold">Free Chip Coupons :</span> will be automatically distributed at <span class="txt-bold">00:00:00</span> (GMT+8) first day of the month, 1 month validity, the unused free chip coupons will be revoke on the next month.
                      <span class="txt-blue">Example :</span> 1<sup>st</sup> January distributed free chips coupon have to be used before 31st January 23:59:59 (GMT+8)
                  </li>
                  <li><span class="txt-bold">Withdrawal rolling :</span> Daily accumulated time start from the same day <span class="txt-bold">00:00:00</span> (GMT+8) to <span class="txt-bold">23:59:59</span> (GMT+8), system will automatically clear the settlement amount of withdrawal rolling on daily <span class="txt-bold">12:00:00</span> (GMT+8) if member did not make the settlement a day before and will be distributed at <span class="txt-bold">18:00:00</span> (GMT+8) on the same day. (Sportsbook based on US EAST TIME (BEIJING TIME – 12 Hours), will be based on payout settlement time.)<br/>
                      <span class="txt-blue">Example :</span> <span class="txt-bold">4<sup>th</sup></span> January <span class="txt-bold">12:00:00</span> (GMT+8) system started automatically begin settlement if member did not make the settlement for 3<sup>rd</sup> January withdrawal rolling and will be distributed at the same day at <span class="txt-bold">18:00:00</span> (GMT+8)
                  </li>
                  <li>
                      <span class="txt-bold">List of games which are unable to enjoy the rebate bonus</span><br/>
                      『<span class="txt-bold">Live Casino</span>』All Live casino Blackjack<br/>
                      『<span class="txt-bold">Slot Games</span>』Video poker, Table games, Fishing Games available in all video galleries<br/>
                      『<span class="txt-bold">Lottery</span>』Yun gu hall, GB game room and all bets from KENO, LOTTERY<br/>
                      『<span class="txt-bold">Sportsbook</span>』All invalid, tie, canceled, both side betting (Against betting odds ) and any bets below 1.70 (European Odds) odds (Malay odds 0.70; Hong Kong odds 0.70; Indonesian odds -1.20; U.S. -120) and non-sports will not be counted in the valid bet. (Greyhound race, Number game/Keno and other rebates are not included).
                  </li>
              </ul>
              <h3>《Coupon Instructions》</h3>
              <ul class="ul-use">
                  <li><span class="txt-blue">Step1.</span> Successfully login member account, click「<span class="txt-red txt-bold">Coupon</span>」at the top, system will redirected the screen , click 「<span class="txt-red txt-bold">Redeem</span>」</li>

                  <li><span class="txt-blue">Step2.</span> According to the instructions on the page，select the favor betting game room、total，enter completed and system will display the transfer amount and bonus which has been transferred successfully into the game room with the required rollover	</li>

                  <li><span class="txt-blue">Step3.</span> Confirm the application and click on「<span class="txt-red txt-bold">OK</span>」button on below, system will be automatically transfer and bind the amount with bonus into the selected transferred game room</li>

                  <li><span class="txt-blue">Step4.</span>Completed betting amount / Withdrawal request，you must first go to the「<span class="txt-red txt-bold">self-promotion</span>」→ 「<span class="txt-red txt-bold">Unlock</span>」，select the game room to be unlocked to submit request，until the system approved，may re-deposited in the game room to bets/ make withdrawal</li>

              </ul>

              <h3>《Promotion Terms & Conditions》</h3>
              <ul class="ul-rule">
                  <li>Promotions are for entertainment purposes only, if founded that the user has more than one account, including same name, same email address, same/similar ip address, same home address, same bank account, same computer and so on with abnormal betting behavior, once discovered, <span class="txt-bold">TBet </span> will retain the right to freeze your account along with profit and balance.
                  </li>
                  <li>Any opposite bets, tie, any hedging betting (cross-site opposite bets) rejected bets, invalid bets, draw or any sports odds less than 1.5 are not counted as required valid bets amount.</li>
                  <li>Any betting done by through third-party illegal software such as 「robot」and 「Open Double / Multiple Windows」may be considered as illegal betting. <span class="txt-bold">TBet</span> reserves the right to freeze the balance of the suspected account and close the member account.</li>
                  <li><span class="txt-bold">TBet</span> reserves the right to check all members' betting records and reserves the right to suspend, cancel or claim back all offers any time if a member breaches the rules and regulations of the event or has any non-entertainment use for profitmaking.</li>
                  <li>If the account is suspected of being abusive and / or not eligible for the promotion, <span class="txt-bold">TBet</span> reserves the right to ask the member to submit relevant supporting documents to verify for identity verification.</li>
                  <li>Any individual / team / organization suspected of using dishonest means or fraud for the purpose to cheat/ abuse of bonus, once verified, <span class="txt-bold">TBet</span> reserves the right to freeze the relevant account profits and balances.</li>
                  <li>By participating in this offer, you are agreeing to the Terms and Conditions of Offer.</li>
                  <li><span class="txt-bold">TBet</span> reserves the right to amend, terminate or the final interpretation of this promotion and to change this event without any prior notice.</li>
                  <li>If found illegal betting situation, shall freeze the deposit (including the amount of profit and bonus), the system will automatically clear the balance to zero (0)</li>
              </ul>
            `
    };
</script>

<!-- <script type="text/javascript">
    var __lc = __lc || {};
    if(window.localStorage['syscode']=='cn'){
        __lc.license=8240881;
        __lc.data_id="ddd58b5cbb";
    }
    if(window.localStorage['syscode']=='my'){
        __lc.license=2816672;
        __lc.data_id="ePiL9a7gMZX";
    }
    if(window.localStorage['syscode']=='hl8'){
        __lc.license=10990282;
        __lc.data_id="10990282";
    }
    (function() {
        var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
        lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
    })();
</script> -->
<script src="common/js/page/vip.js"></script>